"""Full selected v5 corpus qualification, separate from the frozen pilot.

Only passed bodies receive reader payloads. Rejection is inventoried, never
rendered as passed text. These are observed source bodies, not legal states.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
import gzip
import hashlib
import html
import os
from pathlib import Path
import platform
import re
import tarfile
import tempfile
import zlib

from .body_transport import ensure_bundle, _validate_bundle
from .ledger import CATALOG_FIELDS, _directory, _regular, ensure_bundle as source_bundle, list_observations, read_observation
from .source_body_gate import GATE_VERSION, MAX_BYTES, qualify_source_body
from .validation import canonical, digest, file_hash, loads, read_json, require, safe_name, timestamp, unpack_bundle, validate_snapshot, value_hash

CONTRACT = "history-source-body-product-v1"
MEDIA_CONTRACT = "history-source-body-product-v2"
NAME = "bodies.tar.gz"
SHARD_DOCUMENTS = 100
FIXED_ARTIFACTS = {"inventory.jsonl.gz", "last-qualified.jsonl.gz"}
LEGAL = {"status": "unresolved", "from": None, "until": None}
_TOKEN = object()


def _sha(data):
    return hashlib.sha256(data).hexdigest()


_GENERATOR = {"contract": CONTRACT, "gate": GATE_VERSION,
    "sources": {name: _sha((Path(__file__).parent / name).read_bytes().replace(b"\r\n", b"\n"))
                for name in ("source_body_products.py", "source_body_gate.py", "validation.py", "ledger.py", "body_transport.py")},
    "python": platform.python_version(), "zlib": zlib.ZLIB_RUNTIME_VERSION}


def generator_identity(asset_receipt=None):
    result = deepcopy(_GENERATOR)
    if asset_receipt is not None:
        _media_receipt_identity(asset_receipt)
        result["contract"] = MEDIA_CONTRACT
        result["sources"].update({name: _sha((Path(__file__).parent / name).read_bytes().replace(b"\r\n", b"\n"))
                                  for name in ("body_assets.py", "primary_sources.py")})
        result["media_acquisition"] = {"observation_id": asset_receipt["observation_id"],
                                       "receipt_sha256": _sha(canonical(asset_receipt, newline=True))}
    return result


def _media_receipt_identity(receipt):
    """Validate the exact public dependency identity before transport or replay."""
    require(isinstance(receipt, dict) and receipt.get("contract") == "primary-source-acquisition-release-v1"
            and receipt.get("version") == 1, "Unsupported media acquisition receipt")
    identity, project = receipt.get("observation_id"), receipt.get("repository")
    require(digest(identity) and isinstance(project, str)
            and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", project), "Invalid media acquisition identity")
    bundle = receipt.get("bundle", {})
    require(isinstance(bundle, dict) and set(bundle) == {"name", "sha256", "bytes", "url"}
            and bundle["name"] == "snapshot.tar.gz" and digest(bundle["sha256"])
            and type(bundle["bytes"]) is int and 0 < bundle["bytes"] <= 256 * 1024 * 1024,
            "Invalid media acquisition bundle")
    core = {key: value for key, value in receipt.items() if key not in {"observation_id", "release_tag", "receipt_url"}}
    core["bundle"] = {key: value for key, value in bundle.items() if key != "url"}
    base = f"https://github.com/{project}/releases/download/primary-source-{identity}/"
    require(_sha(canonical(core, newline=True)) == identity
            and receipt.get("release_tag") == "primary-source-" + identity
            and receipt.get("receipt_url") == base + "evidence.json"
            and bundle["url"] == base + "snapshot.tar.gz", "Media acquisition identity changed")


def _media_bundle(repository, receipt, local=None):
    _media_receipt_identity(receipt)
    # The generic immutable bundle cache checks exact size/hash. Every adapter
    # independently verifies the complete primary-source acquisition contract.
    return source_bundle(Path(repository), receipt, local)


def _product_cutoff(source_cutoff, assets):
    clocks = ([source_cutoff] if source_cutoff is not None else []) + [a["retrieved_at"] for a in assets]
    return max(clocks, key=lambda value: (timestamp(value), value)) if clocks else None


@contextmanager
def _gzip_writer(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream, gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0, compresslevel=6) as output:
        yield output


def _rows(path):
    with gzip.open(path, "rb") as stream:
        for line in stream:
            row = loads(line)
            require(isinstance(row, dict) and line == canonical(row, newline=True), "Noncanonical body product row")
            yield row


def _no_links(path):
    for item in (path, *path.parents):
        require(not item.is_symlink() and not getattr(item, "is_junction", lambda: False)(), "Linked body product storage")


def read_body_receipt(repository: Path, identity: str) -> dict:
    require(digest(identity), "Expected a body product digest")
    root = Path(repository) / "body-products" / identity; _no_links(root)
    _regular(root / "receipt.json")
    receipt = read_json(root / "receipt.json")
    fields = {"contract", "repository", "observation_id",
        "parent_body_product_id", "comparison_product_id", "generator", "gate_version", "coverage", "legal_valid_time", "knowledge_cutoff",
        "source_receipt_url", "source_bundle_sha256", "snapshot_manifest_sha256", "source_observation_sha256",
        "counts", "shards", "artifact_hashes", "bundle", "body_product_id", "release_tag"}
    media = receipt.get("contract") == MEDIA_CONTRACT
    require(isinstance(receipt, dict) and set(receipt) == fields | ({"source_knowledge_cutoff", "media_dependencies"} if media else set()),
            "Unsupported body receipt fields")
    require((root / "receipt.json").read_bytes() == canonical(receipt, newline=True), "Noncanonical body receipt")
    core = {key: value for key, value in receipt.items() if key not in {"body_product_id", "release_tag"}}
    core["bundle"] = {key: value for key, value in receipt.get("bundle", {}).items() if key != "url"}
    require(receipt.get("contract") in (CONTRACT, MEDIA_CONTRACT) and receipt.get("body_product_id") == identity
            and _sha(canonical(core, newline=True)) == identity, "Body product identity changed")
    require(digest(receipt.get("observation_id")) and (receipt.get("parent_body_product_id") is None
            or digest(receipt["parent_body_product_id"])) and (receipt.get("comparison_product_id") is None
            or digest(receipt["comparison_product_id"])), "Invalid body product lineage")
    project = receipt.get("repository"); bundle = receipt.get("bundle", {})
    require(isinstance(project, str) and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", project)
            and receipt.get("release_tag") == "bodies-" + identity and bundle.get("name") == NAME
            and digest(bundle.get("sha256")) and type(bundle.get("bytes")) is int and bundle["bytes"] > 0
            and bundle.get("url") == f"https://github.com/{project}/releases/download/bodies-{identity}/{NAME}",
            "Invalid body release descriptor")
    require(receipt.get("coverage") == "all_selected_laws_and_regulations_in_accepted_v5_snapshot"
            and receipt.get("legal_valid_time") == LEGAL, "Unsupported body product scope or legal claim")
    require(all(digest(receipt.get(key)) for key in
                ("source_bundle_sha256", "snapshot_manifest_sha256", "source_observation_sha256")), "Invalid body source identity")
    if receipt["knowledge_cutoff"] is not None: timestamp(receipt["knowledge_cutoff"])
    asset_hashes = {}
    if media:
        dependencies = receipt["media_dependencies"]
        require(isinstance(dependencies, dict) and set(dependencies) == {"acquisition_receipt", "assets"},
                "Invalid media dependencies")
        acquisition, assets = dependencies["acquisition_receipt"], dependencies["assets"]
        _media_receipt_identity(acquisition)
        require(isinstance(assets, list) and bool(assets), "V2 body products require used media dependencies")
        urls = []
        for asset in assets:
            require(isinstance(asset, dict) and digest(asset.get("sha256"))
                    and asset.get("path") in {"assets/" + asset["sha256"] + ext for ext in (".png", ".gif", ".jpg")}
                    and type(asset.get("bytes")) is int and asset["bytes"] > 0
                    and asset.get("acquisition_id") == acquisition["observation_id"]
                    and asset.get("acquisition_receipt") == acquisition["receipt_url"]
                    and asset.get("knowledge_cutoff") == asset.get("retrieved_at")
                    and isinstance(asset.get("source_uses"), list) and bool(asset["source_uses"]),
                    "Invalid used media descriptor")
            timestamp(asset["retrieved_at"])
            urls.append(asset.get("source_url"))
            asset_hashes[asset["path"]] = asset["sha256"]
        require(all(isinstance(url, str) for url in urls) and urls == sorted(set(urls)), "Duplicate or unordered media sources")
        source_cutoff = receipt["source_knowledge_cutoff"]
        if source_cutoff is not None: timestamp(source_cutoff)
        require(receipt["knowledge_cutoff"] == _product_cutoff(source_cutoff, assets), "Media product clock differs from used evidence")
        require(receipt["generator"].get("media_acquisition") == {"observation_id": acquisition["observation_id"],
            "receipt_sha256": _sha(canonical(acquisition, newline=True))}, "Generator media dependency differs")
    counts, hashes, shards = receipt.get("counts", {}), receipt.get("artifact_hashes"), receipt.get("shards")
    require(set(counts) == {"selected", "laws", "forskrifter", "passed", "rejected"}
            and all(type(value) is int and value >= 0 for value in counts.values())
            and counts["selected"] == counts["laws"] + counts["forskrifter"] == counts["passed"] + counts["rejected"],
            "Invalid body qualification counts")
    require(isinstance(hashes, dict) and isinstance(shards, list) and len(shards) == len(set(shards))
            and shards == sorted(shards) and all(re.fullmatch(r"documents/[0-9]{5}\.jsonl\.gz", name) for name in shards)
            and set(hashes) == FIXED_ARTIFACTS | set(shards) | set(asset_hashes)
            and all(hashes.get(name) == checksum for name, checksum in asset_hashes.items()), "Invalid body artifact inventory")
    require(all(safe_name(name) == name and digest(sha) for name, sha in hashes.items()), "Invalid body artifact digest")
    require({path.name for path in root.iterdir()} == {"receipt.json"}, "Only the body receipt belongs in Git")
    return receipt


def body_products(repository: Path, *, verify=True) -> list[dict]:
    directory = Path(repository) / "body-products"
    if not directory.exists(): return []
    _no_links(directory); require(directory.is_dir(), "Body products path is not a directory")
    entries = {}
    for path in directory.iterdir():
        require(path.is_dir() and digest(path.name), "Unexpected body product entry")
        entries[path.name] = read_body_receipt(repository, path.name)
    ordered, parent = [], None
    while len(ordered) < len(entries):
        children = [row for row in entries.values() if row["parent_body_product_id"] == parent]
        require(len(children) == 1 and children[0] not in ordered, "Body product chain is disconnected, forked or cyclic")
        require(children[0]["comparison_product_id"] is None or children[0]["comparison_product_id"] in
                {row["body_product_id"] for row in ordered}, "Body comparison is outside its ancestor prefix")
        ordered.append(children[0]); parent = children[0]["body_product_id"]
    if verify:
        for row in ordered: read_body_product(repository, row["body_product_id"])
    return ordered


def _comparison(repository, parent, observation_id, project, *, chain=None, product_knowledge_cutoff=_TOKEN):
    """Select a prior representation without using later source knowledge.

    Global append order and source observation order are distinct. Historical
    reprocessing appends to the former but compares only within the latter.
    """
    chain = body_products(repository, verify=False) if chain is None else chain
    prefix = []
    if parent is not None:
        positions = [i for i, row in enumerate(chain) if row["body_product_id"] == parent]
        require(len(positions) == 1, "Body product parent is not in the accepted chain")
        prefix = chain[:positions[0] + 1]
    accepted = list_observations(repository)
    summaries = {row["observation_id"]: row for row in accepted}
    require(observation_id in summaries, "Body source observation is not accepted")
    # Keep the ledger's deterministic tie ordering, while refusing a source
    # clock to claim knowledge later than the selected target's actual clock.
    ranks = {row["observation_id"]: i for i, row in enumerate(accepted)}
    cutoff = (summaries[observation_id]["knowledge_cutoff"] if product_knowledge_cutoff is _TOKEN
              else product_knowledge_cutoff)
    candidates = []
    for position, row in enumerate(prefix):
        source = summaries.get(row["observation_id"])
        require(source is not None and row.get("source_knowledge_cutoff", row["knowledge_cutoff"]) == source["knowledge_cutoff"],
                "Ancestor body source clock differs from accepted observation")
        old_cutoff = row["knowledge_cutoff"]
        no_later_clock = old_cutoff is None or cutoff is not None and timestamp(old_cutoff) <= timestamp(cutoff)
        if row["repository"] == project and ranks[row["observation_id"]] <= ranks[observation_id] and no_later_clock:
            candidates.append((ranks[row["observation_id"]], position, row["body_product_id"]))
    return max(candidates)[2] if candidates else None


def _check_artifacts(root, receipt):
    _no_links(root); require(root.is_dir(), "Body artifact cache is missing")
    actual = set()
    for path in root.rglob("*"):
        _no_links(path)
        if path.is_file(): actual.add(path.relative_to(root).as_posix())
    require(actual == set(receipt["artifact_hashes"]), "Body artifact membership changed")
    for name, checksum in receipt["artifact_hashes"].items():
        _regular(root / name); require(file_hash(root / name) == checksum, "Body artifact bytes changed")


def artifact_tree(repository: Path, receipt: dict) -> Path:
    root = Path(repository) / ".cache/body-artifacts" / receipt["body_product_id"]
    if not root.exists():
        bundle = ensure_bundle(repository, receipt)
        _directory(root.parent)
        with tempfile.TemporaryDirectory(prefix="unpack-", dir=root.parent) as temporary:
            stage = Path(temporary) / "artifacts"; stage.mkdir()
            with tarfile.open(bundle, "r|gz") as stream:
                for member in stream:
                    name = safe_name(member.name)
                    require(member.isfile() and not member.issparse() and name in receipt["artifact_hashes"], "Invalid body member")
                    path = stage / name; path.parent.mkdir(parents=True, exist_ok=True)
                    with stream.extractfile(member) as incoming, path.open("xb") as output:
                        while chunk := incoming.read(1024 * 1024): output.write(chunk)
            _check_artifacts(stage, receipt)
            try: stage.rename(root)
            except FileExistsError: pass
    _check_artifacts(root, receipt)
    return root


@dataclass(frozen=True)
class _ValidatedInput:
    token: object
    repository: Path
    root: Path
    release: dict
    summary: dict
    manifest: dict
    observation: dict
    members: list


@contextmanager
def _input(repository, observation_id, snapshot=None):
    release, summary, accepted = read_observation(repository, observation_id)
    require(release["snapshot_version"] == 5, "Rich body qualification requires accepted snapshot v5")
    _directory(repository / ".cache")
    with tempfile.TemporaryDirectory(prefix="body-input-", dir=repository / ".cache") as temporary:
        if snapshot is None:
            root = Path(temporary) / "snapshot"; root.mkdir()
            names = unpack_bundle(source_bundle(repository, release), root, release)
        else:
            root = Path(snapshot)
            names = set(read_json(root / "manifest.json")["artifact_hashes"]) | {"manifest.json"}
        require(file_hash(root / "manifest.json") == release["snapshot_manifest_sha256"], "Body source snapshot identity changed")
        manifest, observation, members = validate_snapshot(root, names)
        require(manifest["version"] == 5 and manifest["artifact_hashes"]["source-observations.json"] == summary["source_observation_sha256"]
                and [{key: row[key] for key in CATALOG_FIELDS} for row in members] == accepted,
                "Body input differs from accepted observation")
        yield _ValidatedInput(_TOKEN, repository, root, release, summary, manifest, observation, members)


def _selected(source):
    return [row for row in source.members if row["role"] in ("laws", "forskrifter") and row["selected"]]


def _documents(source):
    """Yield one selected raw member/model at a time, in catalog archive order."""
    chosen = _selected(source)
    for archive in source.observation["archives"]:
        wanted = {row["member_ordinal"]: row for row in chosen if row["archive_ordinal"] == archive["archive_ordinal"]}
        if not wanted: continue
        path = source.root / archive["raw_path"]
        require(file_hash(path) == archive["archive_sha256"], "Body raw archive changed")
        with tarfile.open(path, "r|bz2") as stream:
            for ordinal, member in enumerate(stream):
                if ordinal not in wanted: continue
                row = wanted.pop(ordinal)
                require(member.isfile() and member.name == row["member_path"] and member.size == row["member_size_bytes"]
                        and member.size <= MAX_BYTES, "Body raw member identity/size changed")
                with stream.extractfile(member) as incoming: raw = incoming.read(MAX_BYTES + 1)
                require(len(raw) == member.size and _sha(raw) == row["member_sha256"], "Body raw member bytes changed")
                model_path = source.root / row["selected_output_path"]
                require(file_hash(model_path) == row["selected_output_sha256"], "Selected body model bytes changed")
                model = read_json(model_path)
                require(value_hash(model) == row["parsed_model_sha256"], "Selected body model identity changed")
                yield row, raw, model
        require(not wanted, "Body archive omitted selected members")


def _prior(repository, parent):
    if parent is None: return {}
    receipt = read_body_receipt(repository, parent)
    root = artifact_tree(repository, receipt)
    found = {}
    for row in _rows(root / "last-qualified.jsonl.gz"):
        require(row["refid"] not in found and (row["body_product_id"] == "self" or digest(row["body_product_id"])),
                "Invalid prior qualified inventory")
        value = deepcopy(row)
        if value["body_product_id"] == "self": value["body_product_id"] = parent
        found[row["refid"]] = value
    return found


def _html(refid, fragment, stylesheet):
    return ('<!doctype html>\n<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>' + html.escape(refid) + '</title><style>' + stylesheet + '</style></head><body>' + fragment + '</body></html>\n')


def _classification(old, record):
    if old is None: return "first_qualified_body"
    if old["semantic_sha256"] == record["semantic_sha256"]:
        return "unchanged" if all(old[key] == record[key] for key in ("html_sha256", "stylesheet_sha256")) else "representation_change"
    return "representation_change" if old["raw_member_sha256"] == record["raw_member_sha256"] else "observed_body_change"


def _passed_asset_uses(adapter, report):
    """A passed gate must account for exactly the uses made through its fork."""
    actual = []
    for asset in adapter.used_assets():
        descriptor = {key: value for key, value in asset.items() if key != "source_uses"}
        for use in asset["source_uses"]:
            actual.append(canonical({"original_src": use["original_src"],
                                     "source_use": use["caller_source_use"], "asset": descriptor}))
    reported = [canonical(use) for use in report.get("assets", [])]
    require(sorted(set(actual)) == sorted(set(reported)), "Passed body asset associations differ from acquisition uses")


def _generate(source, output, prior, *, asset_receipt=None, asset_bundle=None):
    adapter = None
    if asset_receipt is not None:
        from .body_assets import BodyAssetAdapter
        adapter = BodyAssetAdapter(asset_receipt, asset_bundle)
    baseline = deepcopy(prior)
    counts = {"selected": 0, "laws": 0, "forskrifter": 0, "passed": 0, "rejected": 0}
    shards, current_name, context, shard = [], None, None, None
    try:
        with _gzip_writer(output / "inventory.jsonl.gz") as inventory:
            for ordinal, (member, raw, model) in enumerate(_documents(source)):
                body = model["source_body"]
                document_adapter = adapter.fork() if adapter is not None else None
                options = {"asset_resolver": document_adapter.resolve} if document_adapter is not None else {}
                result = qualify_source_body(raw, body, expected_member_sha256=member["member_sha256"],
                    expected_refid=member["refid"], source_occurrence_id=member["source_occurrence_id"], **options)
                status = result["report"]["status"]
                require(status in ("passed", "rejected"), "Unsupported body qualification status")
                record = {"ordinal": ordinal, "refid": member["refid"], "role": member["role"], "source_member": member,
                    "source_occurrence_id": member["source_occurrence_id"], "raw_member_sha256": member["member_sha256"],
                    "parsed_model_sha256": member["parsed_model_sha256"], "selected_model_sha256": member["selected_output_sha256"],
                    "source_body_model_sha256": value_hash(body), "body_sha256": body["body_sha256"],
                    "semantic_sha256": body["semantic_sha256"], "status": status, "qualification": result["report"],
                    "comparison": prior.get(member["refid"]), "change": "not_qualified", "payload": None}
                if status == "passed":
                    require(result["html"] is not None and result["stylesheet"] is not None, "Passed body omitted reader payload")
                    if document_adapter is not None:
                        _passed_asset_uses(document_adapter, result["report"])
                        adapter.merge_used(document_adapter)
                    document = {"refid": member["refid"], "source_occurrence_id": member["source_occurrence_id"],
                                "source_body": body, "html": _html(member["refid"], result["html"], result["stylesheet"]),
                                "stylesheet": result["stylesheet"]}
                    name = f"documents/{ordinal // SHARD_DOCUMENTS:05d}.jsonl.gz"
                    if current_name != name:
                        if context is not None: context.__exit__(None, None, None)
                        current_name = name; shards.append(name)
                        context = _gzip_writer(output / name); shard = context.__enter__()
                    data = canonical(document, newline=True); shard.write(data)
                    record.update(html_sha256=_sha(document["html"].encode("utf-8")),
                                  stylesheet_sha256=_sha(document["stylesheet"].encode("utf-8")),
                                  payload={"shard": name, "record_sha256": _sha(data)})
                    record["change"] = _classification(record["comparison"], record)
                    baseline[member["refid"]] = {"body_product_id": "self", **{key: record[key] for key in
                        ("refid", "source_occurrence_id", "raw_member_sha256", "body_sha256", "semantic_sha256", "html_sha256", "stylesheet_sha256")}}
                else:
                    require(result["html"] is None and result["stylesheet"] is None and result["report"].get("reasons"),
                            "Rejected body must have reasons and no reader payload")
                inventory.write(canonical(record, newline=True))
                counts["selected"] += 1; counts[member["role"]] += 1; counts[status] += 1
    finally:
        if context is not None: context.__exit__(None, None, None)
    require(counts["selected"] == len(_selected(source)) == source.manifest["law_count"] + source.manifest["forskrift_count"],
            "Body qualification did not cover every selected document")
    with _gzip_writer(output / "last-qualified.jsonl.gz") as stream:
        for refid in sorted(baseline): stream.write(canonical(baseline[refid], newline=True))
    assets = adapter.export_used(output)["assets"] if adapter is not None else []
    return counts, shards, assets


def _recompare(output, prior):
    """Attach the correct time-bounded prior after passed asset clocks are known.

    Reader shards do not depend on comparison state, so this avoids repeating
    source parsing and qualification just to select the comparison product.
    """
    baseline = deepcopy(prior)
    temporary = output / "inventory-recompare.jsonl.gz"
    with _gzip_writer(temporary) as target:
        for record in _rows(output / "inventory.jsonl.gz"):
            record["comparison"] = prior.get(record["refid"])
            if record["status"] == "passed":
                record["change"] = _classification(record["comparison"], record)
                baseline[record["refid"]] = {"body_product_id": "self", **{key: record[key] for key in
                    ("refid", "source_occurrence_id", "raw_member_sha256", "body_sha256", "semantic_sha256", "html_sha256", "stylesheet_sha256")}}
            target.write(canonical(record, newline=True))
    os.replace(temporary, output / "inventory.jsonl.gz")
    temporary = output / "last-qualified-recompare.jsonl.gz"
    with _gzip_writer(temporary) as target:
        for refid in sorted(baseline): target.write(canonical(baseline[refid], newline=True))
    os.replace(temporary, output / "last-qualified.jsonl.gz")


def _audit(source, receipt, root, prior, *, asset_bundle=None):
    require(source.token is _TOKEN and source.release["observation_id"] == receipt["observation_id"], "Wrong validated body input")
    require(receipt["source_receipt_url"] == source.release["receipt_url"]
            and receipt["source_bundle_sha256"] == source.release["bundle"]["sha256"]
            and receipt["snapshot_manifest_sha256"] == source.release["snapshot_manifest_sha256"]
            and receipt["source_observation_sha256"] == source.summary["source_observation_sha256"]
            and receipt.get("source_knowledge_cutoff", receipt["knowledge_cutoff"]) == source.observation["knowledge_cutoff"]
            and receipt["gate_version"] == GATE_VERSION, "Body product source/gate binding changed")
    dependencies = receipt.get("media_dependencies")
    acquisition = dependencies["acquisition_receipt"] if dependencies else None
    retained_assets = _media_bundle(source.repository, acquisition, asset_bundle) if acquisition is not None else None
    with tempfile.TemporaryDirectory(prefix="body-audit-", dir=source.repository / ".cache") as temporary:
        expected = Path(temporary)
        counts, shards, assets = _generate(source, expected, prior, asset_receipt=acquisition, asset_bundle=retained_assets)
        require(counts == receipt["counts"] and shards == receipt["shards"], "Body qualification inventory changed")
        require(assets == (dependencies["assets"] if dependencies else []), "Used media dependencies differ from passed source bodies")
        require(receipt["knowledge_cutoff"] == _product_cutoff(source.observation["knowledge_cutoff"], assets),
                "Body product knowledge clock differs from used evidence")
        expected_files = {p.relative_to(expected).as_posix() for p in expected.rglob("*") if p.is_file()}
        require(expected_files == set(receipt["artifact_hashes"]), "Rebuilt body artifact inventory differs")
        for name in receipt["artifact_hashes"]:
            # The published gzip bytes retain their own exact digest. Comparing
            # canonical uncompressed bytes permits equivalent zlib runtimes.
            if name.startswith("assets/"):
                require((root / name).read_bytes() == (expected / name).read_bytes(), "Used binary asset differs from acquired bytes")
            else:
                with gzip.open(root / name, "rb") as actual, gzip.open(expected / name, "rb") as rebuilt:
                    require(hashlib.file_digest(actual, "sha256").hexdigest() == hashlib.file_digest(rebuilt, "sha256").hexdigest(),
                            "Body qualification or prior-qualified inventory differs from source")


def read_body_product(repository: Path, identity: str, *, snapshot: Path | None = None,
                      ledger_repository: Path | None = None, artifacts: Path | None = None, _validated=None,
                      asset_bundle: Path | None = None) -> dict:
    """Full audit: exact artifact bytes, validated v5 source, all gate outcomes."""
    repository = Path(repository).absolute(); ledger = Path(ledger_repository or repository).absolute()
    receipt = read_body_receipt(repository, identity)
    root = Path(artifacts) if artifacts is not None else artifact_tree(ledger, receipt)
    _check_artifacts(root, receipt)
    comparison = _comparison(ledger, receipt["parent_body_product_id"], receipt["observation_id"], receipt["repository"],
                             product_knowledge_cutoff=receipt["knowledge_cutoff"])
    require(receipt["comparison_product_id"] == comparison, "Body comparison differs from eligible accepted source history")
    prior = _prior(ledger, comparison)
    if _validated is not None:
        require(isinstance(_validated, _ValidatedInput) and _validated.token is _TOKEN and _validated.repository == ledger,
                "Invalid invocation-local validation context")
        _audit(_validated, receipt, root, prior, asset_bundle=asset_bundle)
    else:
        with _input(ledger, receipt["observation_id"], snapshot) as source:
            _audit(source, receipt, root, prior, asset_bundle=asset_bundle)
    return receipt


def _bundle(output, path, hashes):
    with path.open("xb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=1) as zipped:
        with tarfile.open(fileobj=zipped, mode="w|") as stream:
            for name in sorted(hashes):
                file = output / name; require(file_hash(file) == hashes[name], "Body artifact changed before bundling")
                info = tarfile.TarInfo(name); info.size = file.stat().st_size; info.mode = 0o644; info.mtime = 0
                with file.open("rb") as incoming: stream.addfile(info, incoming)
    return {"name": NAME, "sha256": file_hash(path), "bytes": path.stat().st_size}


def qualify_bodies(repository: Path, observation_id: str, expected_parent="auto", snapshot: Path | None = None,
                   github_repository="sondreskarsten/norwegian-laws-history", *, verify_replay=True, reuse_existing_observation=False,
                   asset_receipt: dict | None = None, asset_bundle: Path | None = None) -> dict:
    repository = Path(repository).absolute(); _directory(repository / ".cache")
    require(isinstance(github_repository, str) and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", github_repository), "Invalid body repository")
    lock = repository / ".cache/body-writer.lock"
    try: descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc: raise ValueError("Body writer lock exists; inspect its prior writer before retrying") from exc
    try:
        os.close(descriptor)
        chain = body_products(repository, verify=False)
        parent = chain[-1]["body_product_id"] if chain else None
        require(expected_parent == "auto" or expected_parent == parent or expected_parent == "none" and parent is None,
                "Body product parent changed")
        require(asset_receipt is not None or asset_bundle is None, "An asset bundle requires its exact acquisition receipt")
        retained_assets = _media_bundle(repository, asset_receipt, asset_bundle) if asset_receipt is not None else None
        generator = generator_identity(asset_receipt) if asset_receipt is not None else generator_identity()
        for old in reversed(chain):
            same_dependency = (asset_receipt is None or old.get("media_dependencies", {}).get("acquisition_receipt") == asset_receipt)
            if old["observation_id"] == observation_id and old["repository"] == github_repository and same_dependency and (reuse_existing_observation or old["generator"] == generator):
                if verify_replay: read_body_product(repository, old["body_product_id"], snapshot=snapshot, asset_bundle=retained_assets)
                return {"status": "already_present", **old}
        comparison = _comparison(repository, parent, observation_id, github_repository, chain=chain) if asset_receipt is None else None
        prior = _prior(repository, comparison) if asset_receipt is None else {}
        with _input(repository, observation_id, snapshot) as source, tempfile.TemporaryDirectory(prefix="body-product-", dir=repository / ".cache") as temporary:
            work = Path(temporary); output = work / "artifacts"; output.mkdir()
            counts, shards, assets = _generate(source, output, prior, asset_receipt=asset_receipt, asset_bundle=retained_assets)
            product_cutoff = _product_cutoff(source.observation["knowledge_cutoff"], assets)
            if asset_receipt is not None:
                require(bool(assets), "No passed bodies used acquired assets; use v1 qualification without media dependencies")
                comparison = _comparison(repository, parent, observation_id, github_repository, chain=chain,
                                         product_knowledge_cutoff=product_cutoff)
                _recompare(output, _prior(repository, comparison))
            names = FIXED_ARTIFACTS | set(shards) | {asset["path"] for asset in assets}
            hashes = {name: file_hash(output / name) for name in sorted(names)}
            bundle = work / NAME
            core = {"contract": MEDIA_CONTRACT if asset_receipt is not None else CONTRACT, "repository": github_repository, "observation_id": observation_id,
                "parent_body_product_id": parent, "comparison_product_id": comparison, "generator": generator, "gate_version": GATE_VERSION,
                "coverage": "all_selected_laws_and_regulations_in_accepted_v5_snapshot", "legal_valid_time": deepcopy(LEGAL),
                "knowledge_cutoff": product_cutoff, "source_receipt_url": source.release["receipt_url"],
                "source_bundle_sha256": source.release["bundle"]["sha256"], "snapshot_manifest_sha256": source.release["snapshot_manifest_sha256"],
                "source_observation_sha256": source.summary["source_observation_sha256"], "counts": counts, "shards": shards,
                "artifact_hashes": hashes, "bundle": _bundle(output, bundle, hashes)}
            if asset_receipt is not None:
                core.update(source_knowledge_cutoff=source.observation["knowledge_cutoff"],
                            media_dependencies={"acquisition_receipt": deepcopy(asset_receipt), "assets": assets})
            identity = _sha(canonical(core, newline=True)); tag = "bodies-" + identity
            receipt = {**core, "body_product_id": identity, "release_tag": tag,
                       "bundle": {**core["bundle"], "url": f"https://github.com/{github_repository}/releases/download/{tag}/{NAME}"}}
            stage = work / "body-products" / identity; stage.mkdir(parents=True)
            (stage / "receipt.json").write_bytes(canonical(receipt, newline=True))
            verified = read_body_product(work, identity, ledger_repository=repository, artifacts=output,
                                         _validated=source, asset_bundle=retained_assets)
            cache = repository / ".cache/body-bundles"; _directory(cache)
            target = cache / (receipt["bundle"]["sha256"] + ".tar.gz")
            if target.exists(): _validate_bundle(target, receipt)
            else: os.link(bundle, target)
            artifacts = repository / ".cache/body-artifacts" / identity; _directory(artifacts.parent)
            if artifacts.exists(): _check_artifacts(artifacts, receipt)
            else: output.rename(artifacts)
            destination = repository / "body-products" / identity; _directory(destination.parent)
            require(not destination.exists(), "Unexpected existing body product destination")
            stage.rename(destination)
            return {"status": "accepted", **verified}
    finally:
        lock.unlink()


def qualify_all(repository: Path, github_repository="sondreskarsten/norwegian-laws-history") -> list[dict]:
    results = []
    for observation in list_observations(repository):
        release, _, _ = read_observation(repository, observation["observation_id"])
        if release["snapshot_version"] != 5: continue
        results.append(qualify_bodies(repository, observation["observation_id"], github_repository=github_repository,
                                      verify_replay=False, reuse_existing_observation=True))
    return results
