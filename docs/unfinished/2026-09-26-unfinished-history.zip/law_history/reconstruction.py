"""One explicit partial original-baseline method; never today's-text fallback.

This is deliberately not a general legal amendment engine. A reviewed method
pins its source, interpretation clock, coverage audit and date-level window.
It can return PARTIAL source text, or UNAVAILABLE with concrete gaps. Existing
observation, product, proposal and full legal-eligibility contracts are untouched.
"""
from __future__ import annotations

from datetime import date
import gzip
import hashlib
import html
from pathlib import Path
import re
from xml.etree import ElementTree as ET

from .ledger import CATALOG_FIELDS, list_observations, read_observation
from .operations import _xml_index, _text
from . import source_body_gate as gate
from .validation import file_hash, loads, read_json, require, safe_name, timestamp, value_hash

CONTRACT = "history-partial-reconstruction-v1"
REGISTRY_DIRECTORY = Path(__file__).parent / "pilot_evidence"
METHODS = {
    "forskrift/2026-09-10-1780": (
        "for-2026-09-10-1780",
        "fad9a7d77e3c5f3e4366c1d7d80ca4e0011bd2cc1370f2705f94591dfa81a195",
    ),
}


def _calendar(value):
    require(isinstance(value, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", value),
            "legal-date must be an ISO calendar date, YYYY-MM-DD")
    return date.fromisoformat(value)


def _artifact(root, name, expected_hash):
    path = root / safe_name(name)
    for part in (path, *path.parents):
        require(not part.is_symlink() and not getattr(part, "is_junction", lambda: False)(),
                "Linked pilot evidence is not permitted")
    require(path.is_file() and file_hash(path) == expected_hash,
            f"Pilot evidence binding changed: {name}")
    return path


def _method(refid):
    folder, expected = METHODS[refid]
    root = REGISTRY_DIRECTORY / folder
    registry = read_json(_artifact(root, "registry.json", expected))
    require(registry["contract"] == "history-partial-reconstruction-method-v1"
            and registry["refid"] == refid
            and registry["eligibility_scope"] == "partial_source_based_baseline_only"
            and registry["full_legal_eligibility"] is False
            and registry["applied_operations"] == [], "Unsupported reconstruction method")
    coverage = read_json(_artifact(root, registry["coverage"]["path"], registry["coverage"]["sha256"]))
    require(coverage["contract"] == "history-pilot-coverage-audit-v1"
            and coverage["refid"] == refid, "Coverage target differs from registered method")
    return root, registry, coverage, expected


def _capture(raw):
    """Capture original ordered XML; independent gate rereads every raw event."""
    root = ET.fromstring(raw)
    head, body = root.find("head"), root.find("body")
    require(head is not None and body is not None, "Original source envelope is missing")
    mains = body.findall('main[@class="documentBody"]')
    require(len(mains) == 1, "Original source body is missing or ambiguous")

    def node(element):
        children = [element.text] if element.text else []
        for child in element:
            children.append(node(child))
            if child.tail:
                children.append(child.tail)
        return {"tag": element.tag, "attributes": dict(element.attrib), "children": children}

    tree = node(mains[0])
    base, identity = head.find("base"), root.find('.//dd[@class="refid"]')
    require(base is not None and identity is not None, "Original source identity is missing")
    context = {"html_lang": root.get("lang"), "html_attributes": dict(root.attrib),
               "head_attributes": dict(head.attrib), "body_attributes": dict(body.attrib),
               "source_base": base.get("href"), "refid": "".join(identity.itertext()).strip()}
    return {"contract": gate.CONTRACT, "member_sha256": hashlib.sha256(raw).hexdigest(),
            "context": context, "root": tree, "body_sha256": value_hash(tree),
            "semantic_sha256": value_hash([gate.CONTRACT, context, tree])}


def _verified_coverage(repository, root, registry, coverage):
    """Bind retained audit rows to entire accepted contemporary XML inventories."""
    catalogs = {}
    for identity, pin in coverage["evidence_observations"].items():
        _, summary, members = read_observation(repository, identity)
        require(all(summary.get(key) == value for key, value in pin.items()),
                "Registered coverage observation binding changed")
        catalogs[identity] = members
    for label in ("baseline", "current_corroboration"):
        binding = registry[label]
        matches = [r for r in catalogs[binding["observation_id"]]
                   if r["source_occurrence_id"] == binding["source_occurrence_id"]]
        require(len(matches) == 1 and all(matches[0][key] == binding[key] for key in CATALOG_FIELDS),
                f"Registered {label} member binding changed")
    require(registry["baseline"]["role"] == "amendment_acts", "Baseline must be original Lovtidend evidence")
    expected = {}
    for archive in coverage["archives"]:
        sha = archive["archive_sha256"]
        rows = [r for r in catalogs[archive["accepted_observation"]]
                if r["archive_sha256"] == sha and r["member_type"] == "file"
                and r["member_path"].endswith(".xml")]
        require(len(rows) == archive["verified_xml_members"], "Coverage archive inventory changed")
        for row in rows:
            require(row["role"] == "amendment_acts", "Coverage includes a different source role")
            expected[(sha, row["member_ordinal"])] = row
    index = coverage["index"]
    compressed = _artifact(root, index["path"], index["sha256"]).read_bytes()
    content = gzip.decompress(compressed)
    require(hashlib.sha256(content).hexdigest() == index["uncompressed_sha256"], "Coverage index binding changed")
    seen, matches = set(), []
    for line in content.splitlines():
        row = loads(line)
        key = row["archive_sha256"], row["member_ordinal"]
        require(key in expected and key not in seen, "Coverage index has missing, duplicate or unexpected members")
        require(all(row[field] == expected[key][field] for field in ("refid", "member_sha256")),
                "Coverage scan member binding changed")
        seen.add(key)
        if row["matches"].get(registry["refid"]):
            require(row["refid"] == registry["refid"]
                    and row["member_sha256"] == registry["baseline"]["member_sha256"],
                    "Unresolved target candidate in pilot coverage")
            matches.append({"archive_sha256": key[0], "member_ordinal": key[1],
                            "source_occurrence_id": expected[key]["source_occurrence_id"],
                            "matches": row["matches"][registry["refid"]]})
    require(seen == set(expected) and len(seen) == index["xml_occurrences"]
            and len(matches) == 2, "Coverage scan is incomplete")
    return {"status": "verified_retained_audit_with_documented_limits",
            "coverage_sha256": registry["coverage"]["sha256"], "index_sha256": index["sha256"],
            "verified_xml_occurrences": len(seen), "archives": coverage["archives"],
            "evidence_observations": list(coverage["evidence_observations"].values()),
            "target_matches": matches, "applied_operations": [],
            "assumptions": coverage["assumptions"], "gaps": coverage["gaps"],
            "search_patterns": coverage["search_patterns"],
            "publication_window": {k: v for k, v in coverage["publication_window"].items() if k != "documents"}}


def _original(root, registry):
    binding = registry["baseline"]
    raw = _artifact(root, binding["raw_path"], binding["member_sha256"]).read_bytes()
    require(len(raw) == binding["member_size_bytes"], "Original member length changed")
    model = _capture(raw)
    require(model["body_sha256"] == binding["body_sha256"]
            and model["semantic_sha256"] == binding["semantic_sha256"], "Original body binding changed")
    nodes, paths, _ = _xml_index(raw)
    main = next(n for n in nodes if n.tag == "main")
    markers = [{"path": paths[n], "data_name": n.get("data-name"),
                "data_li_identifier": n.get("data-li-identifier")}
               for n in main.iter() if n.tag == "li"]
    require(markers == binding["list_markers"] and len(markers) == 29,
            "Original literal list markers changed")
    commencement = registry["commencement"]
    statements = [n for n in nodes if paths[n] == commencement["source_path"]]
    require(len(statements) == 1 and statements[0].get("id") == commencement["source_element_id"]
            and _text(statements[0]) == commencement["source_text"], "Commencement source binding changed")
    header = next(n for n in nodes if n.tag == "dd" and n.get("class") == "dateInForce")
    require(_text(header) == commencement["header_date_in_force"] == commencement["date"],
            "Commencement header and registered date differ")
    result = gate.qualify_source_body(raw, model, expected_refid=registry["refid"],
        expected_member_sha256=binding["member_sha256"], source_occurrence_id=binding["source_occurrence_id"])
    require(result["report"]["status"] == "passed", f"Original body qualification failed: {result['report']}")
    require(result["report"]["element_counts"].get("ul") == binding["list_count"] == 8,
            "Original list hierarchy changed")
    # Gate qualification includes complete raw comparison and rendered reverse check.
    return result


def reconstruct(repository: Path, refid: str, legal_date: str, known_at: str | None = None) -> dict:
    """Return the registered PARTIAL pilot or an explicit, non-fallback gap.

    Omitted known_at resolves to the latest accepted source/interpretation clock.
    Passing that exact returned timestamp selects the same evidence and coverage.
    """
    legal = _calendar(legal_date)
    requested_cutoff = timestamp(known_at) if known_at is not None else None
    accepted = list_observations(Path(repository))
    clocks = [timestamp(s["knowledge_cutoff"]) for s in accepted if s["knowledge_cutoff"] is not None]
    root = registry = coverage = method_hash = None
    if refid in METHODS:
        root, registry, coverage, method_hash = _method(refid)
        clocks.append(timestamp(registry["interpretation_recorded_at"]))
    resolved = requested_cutoff if requested_cutoff is not None else max(clocks, default=None)
    included = [s for s in accepted if s["knowledge_cutoff"] is not None
                and resolved is not None and timestamp(s["knowledge_cutoff"]) <= resolved]
    response = {"contract": CONTRACT, "status": "UNAVAILABLE", "refid": refid,
        "requested_legal_date": legal_date, "requested_known_at": known_at,
        "resolved_known_at": resolved.isoformat() if resolved is not None else None,
        "source_knowledge_cutoff": registry["source_knowledge_cutoff"] if registry else None,
        "interpretation_recorded_at": registry["interpretation_recorded_at"] if registry else None,
        "scope": "partial_source_based_original_baseline", "full_legal_eligibility": False,
        "partial_baseline_eligible": False, "baseline": None, "document": None,
        "applied_operations": [], "coverage": None, "gaps": []}

    def gap(code, detail, **evidence):
        response["gaps"].append({"code": code, "detail": detail, **evidence})

    if registry is None:
        gap("unsupported_document", "No explicit partial reconstruction method is registered for this refid.")
        return response
    if resolved < timestamp(registry["interpretation_recorded_at"]):
        gap("interpretation_not_recorded_at_cutoff", "The registered interpretation was recorded after this known-at cutoff.")
    if resolved < timestamp(registry["source_knowledge_cutoff"]):
        gap("source_evidence_not_known_at_cutoff", "The required retained source evidence was observed after this cutoff.")
    if response["gaps"]:
        # Do not disclose the later method's commencement statement or legal
        # window when answering an earlier knowledge-cutoff request.
        return response
    response.update(method_id=registry["method_id"], registry_sha256=method_hash,
                    supported_pilot_window=registry["supported_pilot_window"],
                    commencement=registry["commencement"], cited_source_basis=registry["cited_source_basis"],
                    limitations=registry["limitations"])
    if legal < _calendar(registry["commencement"]["date"]):
        gap("before_source_commencement", "The requested date precedes the original source's explicit commencement.")
    window = registry["supported_pilot_window"]
    if not _calendar(window["from_inclusive"]) <= legal < _calendar(window["until_exclusive"]):
        gap("outside_supported_pilot_window", "No reconstruction is qualified outside this deliberately bounded pilot window.")
    for summary in accepted:
        if summary["knowledge_cutoff"] is None:
            gap("unassessed_source_time", "Accepted source evidence has no known observation clock.",
                observation_id=summary["observation_id"])
    assessed = registry["assessed_observations"]
    equivalent = []
    assessed_catalogs = {pin["catalog_sha256"] for pin in assessed.values()}
    for summary in included:
        pin = assessed.get(summary["observation_id"])
        if pin is None:
            # list_observations has verified each complete catalog. Exact
            # catalog equality means no new source member, selection or role;
            # it does not extend the registered legal-date window.
            if summary["catalog_sha256"] in assessed_catalogs:
                equivalent.append({key: summary[key] for key in
                    ("observation_id", "catalog_sha256", "knowledge_cutoff")})
            else:
                gap("unassessed_accepted_source_evidence", "Accepted source evidence requires a new coverage assessment; stale coverage cannot be reused.",
                    observation_id=summary["observation_id"], knowledge_cutoff=summary["knowledge_cutoff"])
        else:
            require(all(summary.get(key) == value for key, value in pin.items()), "Assessed observation binding changed")
    included_ids = {s["observation_id"] for s in included}
    missing = set(coverage["evidence_observations"]) - included_ids
    if missing:
        gap("required_observation_unavailable", "Required coverage observations are absent at the requested cutoff.",
            observation_ids=sorted(missing))
    if response["gaps"]:
        return response
    checked_coverage = _verified_coverage(Path(repository), root, registry, coverage)
    checked_coverage["equivalent_catalog_observations"] = equivalent
    qualified = _original(root, registry)
    baseline = registry["baseline"]
    document_html = ('<!doctype html><html lang="nb"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{html.escape(baseline["title"])}</title><style>{qualified["stylesheet"]}</style>'
        '</head><body><p>PARTIAL: kildebasert rekonstruksjon innen et avgrenset prøveintervall.</p>'
        + qualified["html"] + '</body></html>')
    response.update(status="PARTIAL", partial_baseline_eligible=True,
        baseline={key: value for key, value in baseline.items() if key not in {"raw_path", "list_markers"}},
        source_publication=registry["source_publication"], coverage=checked_coverage,
        document={"title": baseline["title"], "html": document_html,
                  "source_body_html": qualified["html"], "stylesheet": qualified["stylesheet"],
                  "qualification": qualified["report"], "literal_list_marker_count": len(baseline["list_markers"])},
        gaps=[{"code": "partial_scope_limit", "detail": detail} for detail in coverage["gaps"]])
    return response
