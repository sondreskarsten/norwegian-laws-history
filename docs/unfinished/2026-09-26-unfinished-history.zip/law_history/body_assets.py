"""Source-bound raster assets; container checks are not full image decoding.

Acquisition records establish retrieved bytes and clocks, not an association to
an XML node. The body gate must independently check each caller-supplied use.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import io
from pathlib import Path
import struct
import tarfile
from urllib.parse import urljoin, urlsplit
import zlib

from .primary_sources import verify_primary_sources
from .validation import canonical, require, timestamp

CONTRACT = "observed-body-raster-asset-v1"
MEDIA_CHECK = "raster-signature-container-boundaries-v1-not-full-image-decoding"
SOURCE_BASE = "https://lovdata.no/"


def _container(data: bytes) -> tuple[str, str, int]:
    """Check format signatures, bounded records, dimensions and final markers."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        offset, tags, image_bytes = 8, [], 0
        while offset < len(data):
            require(offset + 12 <= len(data), "Truncated PNG chunk")
            size = int.from_bytes(data[offset:offset+4], "big")
            tag = data[offset+4:offset+8]; end = offset + 12 + size
            require(end <= len(data), "Truncated PNG content")
            content = data[offset+8:end-4]
            require(zlib.crc32(tag + content) == int.from_bytes(data[end-4:end], "big"), "PNG chunk CRC mismatch")
            if not tags:
                require(tag == b"IHDR" and size == 13 and all(struct.unpack(">II", content[:8])), "Invalid PNG header")
                depth, colour, compression, filtering, interlace = content[8:]
                require(depth in {0: {1, 2, 4, 8, 16}, 2: {8, 16}, 3: {1, 2, 4, 8},
                                  4: {8, 16}, 6: {8, 16}}.get(colour, set())
                        and compression == filtering == 0 and interlace in (0, 1), "Invalid PNG header fields")
            else:
                require(tag != b"IHDR", "Duplicate PNG header")
            if tag == b"IDAT": image_bytes += size
            tags.append(tag); offset = end
            if tag == b"IEND":
                require(size == 0 and image_bytes > 0, "Incomplete PNG content")
                return "image/png", "png", offset
        raise ValueError("Missing PNG end marker")
    if data.startswith((b"GIF87a", b"GIF89a")):
        require(len(data) >= 13 and all(struct.unpack("<HH", data[6:10])), "Invalid GIF header")
        offset = 13 + (3 * (2 ** ((data[10] & 7) + 1)) if data[10] & 128 else 0)
        images = 0

        def blocks(position, *, image=False):
            count = 0
            while True:
                require(position < len(data), "Truncated GIF data blocks")
                size = data[position]; position += 1
                if not size:
                    require(not image or count, "Missing GIF image data")
                    return position
                require(position + size <= len(data), "Truncated GIF block")
                position += size; count += size

        while offset < len(data):
            marker = data[offset]; offset += 1
            if marker == 0x3B:
                require(images, "Incomplete GIF content")
                return "image/gif", "gif", offset
            if marker == 0x21:
                require(offset < len(data), "Truncated GIF extension")
                offset = blocks(offset + 1)
            elif marker == 0x2C:
                require(offset + 9 <= len(data) and all(struct.unpack("<HH", data[offset+4:offset+8])), "Invalid GIF image descriptor")
                packed = data[offset+8]; offset += 9
                if packed & 128: offset += 3 * (2 ** ((packed & 7) + 1))
                require(offset < len(data) and 2 <= data[offset] <= 8, "Invalid GIF LZW size")
                offset = blocks(offset + 1, image=True); images += 1
            else:
                raise ValueError("Unknown GIF block")
        raise ValueError("Missing GIF trailer")
    if data.startswith(b"\xff\xd8"):
        offset, frames, scans = 2, 0, 0
        while offset < len(data):
            require(data[offset] == 255, "Invalid JPEG marker boundary")
            while offset < len(data) and data[offset] == 255: offset += 1
            require(offset < len(data), "Truncated JPEG marker")
            marker = data[offset]; offset += 1
            if marker == 0xD9:
                require(frames and scans, "Incomplete JPEG content")
                return "image/jpeg", "jpg", offset
            require(marker not in {0, 0xD8, 1, *range(0xD0, 0xD8)}, "Unexpected JPEG marker")
            require(offset + 2 <= len(data), "Truncated JPEG length")
            size = int.from_bytes(data[offset:offset+2], "big")
            require(size >= 2 and offset + size <= len(data), "Truncated JPEG segment")
            if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
                require(size >= 8 and all(struct.unpack(">HH", data[offset+3:offset+7])), "Invalid JPEG frame dimensions")
                frames += 1
            offset += size
            if marker == 0xDA:
                scans += 1
                scan_start = offset
                while True:
                    boundary = data.find(b"\xff", offset)
                    require(boundary >= 0 and boundary + 1 < len(data), "Truncated JPEG scan")
                    after = boundary + 1
                    while after < len(data) and data[after] == 255: after += 1
                    require(after < len(data), "Truncated JPEG scan marker")
                    if data[after] == 0 or 0xD0 <= data[after] <= 0xD7:
                        offset = after + 1
                    else:
                        require(boundary > scan_start, "Missing JPEG scan data")
                        offset = boundary; break
        raise ValueError("Missing JPEG end marker")
    raise ValueError("Unsupported raster media signature")


def _media(data: bytes) -> tuple[str, str]:
    media, extension, _ = _container(data)
    return media, extension


def _url(value):
    require(isinstance(value, str) and value and not any(c.isspace() or ord(c) < 32 for c in value)
            and "\\" not in value, "Invalid source image URL")
    url = urljoin(SOURCE_BASE, value); parsed = urlsplit(url)
    require(parsed.scheme == "https" and parsed.hostname == "lovdata.no"
            and not parsed.username and not parsed.password and parsed.port in (None, 443)
            and not parsed.fragment, "Image URL outside the retained source origin")
    return url


class BodyAssetAdapter:
    """Verified acquisition snapshot with explicit, deterministic used-asset export."""

    def __init__(self, receipt: dict, bundle: Path):
        receipt = deepcopy(receipt)
        verified = verify_primary_sources(receipt, bundle)
        raw = Path(bundle).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == receipt["bundle"]["sha256"], "Acquisition changed after verification")
        self._receipt = receipt
        self._snapshot_token = object()
        self._rows = {}
        for row in verified["sources"]:
            self._rows.setdefault(row["url"], []).append(deepcopy(row))
        self._bytes = {}
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
            for member in archive:
                if member.name != "manifest.json":
                    self._bytes[member.name] = archive.extractfile(member).read()
        self._used = {}

    def fork(self):
        """Reuse this verified snapshot with a fresh per-document use tracker."""
        child = object.__new__(BodyAssetAdapter)
        child._receipt = self._receipt
        child._rows = self._rows
        child._bytes = self._bytes
        child._snapshot_token = self._snapshot_token
        child._used = {}
        return child

    def merge_used(self, other):
        """Merge only explicit uses from a fork of this verified acquisition."""
        require(type(other) is BodyAssetAdapter
                and other._snapshot_token is self._snapshot_token
                and other._receipt['observation_id'] == self._receipt['observation_id'],
                "Cannot merge assets from another verified acquisition snapshot")
        for url, entry in other._used.items():
            current = self._used.setdefault(url, {"asset": deepcopy(entry['asset']), "uses": {}})
            require(current['asset'] == entry['asset'], "Conflicting verified asset descriptor")
            current['uses'].update(deepcopy(entry['uses']))

    def resolve(self, src: str, *, source_use: dict) -> dict:
        url = _url(src)
        rows = self._rows.get(url, [])
        require(len(rows) == 1, "Image acquisition is missing or ambiguous")
        row = rows[0]
        require(row.get("status") == 200 and "path" in row and not row.get("error")
                and not row.get("content_range"), "Image acquisition is failed or partial")
        require(_url(row.get("final_url", row["url"])) == row["url"], "Image acquisition redirected away from its exact source URL")
        data = self._bytes[row["path"]]
        require(len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"], "Image source bytes changed")
        media, extension, container_bytes = _container(data)
        declared = row.get("content_type", "").split(";", 1)[0].strip().lower()
        require(isinstance(source_use, dict) and bool(source_use), "Explicit caller source-use provenance required")
        canonical(source_use)
        descriptor = {"contract": CONTRACT, "sha256": row["sha256"], "bytes": len(data),
            "path": f'assets/{row["sha256"]}.{extension}', "media_type": media,
            "declared_content_type": row.get("content_type"),
            "declared_media_type_matches_signature": declared == media,
            "container_bytes": container_bytes,
            "trailing_bytes": len(data) - container_bytes,
            "trailing_bytes_policy": "preserved_exactly_after_complete_raster_container_not_interpreted",
            "verification": MEDIA_CHECK, "source_url": url,
            "retrieved_at": row["retrieved_at"], "knowledge_cutoff": row["retrieved_at"],
            "knowledge_cutoff_basis": "asset_retrieval_not_xml_observation",
            "acquisition_id": self._receipt["observation_id"],
            "acquisition_receipt": self._receipt["receipt_url"],
            "acquisition_record": deepcopy(row), "source_association": "requires_independent_xml_gate_check"}
        entry = self._used.setdefault(url, {"asset": descriptor, "uses": {}})
        use = {"original_src": src, "resolved_url": url, "caller_source_use": deepcopy(source_use)}
        entry["uses"][canonical(use)] = use
        return deepcopy(descriptor)

    @property
    def knowledge_cutoff(self):
        clocks = [entry["asset"]["retrieved_at"] for entry in self._used.values()]
        return max(clocks, key=lambda value: (timestamp(value), value)) if clocks else None

    def used_assets(self):
        return [{**deepcopy(entry["asset"]), "source_uses": [deepcopy(entry["uses"][key]) for key in sorted(entry["uses"])]}
                for _, entry in sorted(self._used.items())]

    def export_used(self, output: Path):
        output = Path(output)
        require(not any(p.is_symlink() or getattr(p, "is_junction", lambda: False)()
                        for p in (output, *output.parents)), "Linked asset output directory")
        output.mkdir(parents=True, exist_ok=True)
        assets = output / "assets"
        require(not assets.is_symlink() and not getattr(assets, "is_junction", lambda: False)(), "Linked assets directory")
        assets.mkdir(exist_ok=True)
        for entry in self._used.values():
            descriptor = entry["asset"]; target = output / descriptor["path"]
            data = self._bytes[descriptor["acquisition_record"]["path"]]
            require(not target.is_symlink() and not getattr(target, "is_junction", lambda: False)(), "Linked asset output")
            if target.exists():
                require(target.is_file() and target.read_bytes() == data, "Existing asset differs; refusing overwrite")
            else:
                with target.open("xb") as stream: stream.write(data)
            require(target.read_bytes() == data, "Exported asset readback differs")
        return {"contract": CONTRACT, "knowledge_cutoff": self.knowledge_cutoff, "assets": self.used_assets()}
