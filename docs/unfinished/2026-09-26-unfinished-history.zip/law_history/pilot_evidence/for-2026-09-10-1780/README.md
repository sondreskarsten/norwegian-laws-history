# Partial original-baseline method for FOR-2026-09-10-1780

This registry enables only `PARTIAL` source-text reconstruction on **2026-09-21 and 2026-09-22**. The original § 11 expressly commences the regulation on 21 September. The two-day scope covers that initial day and the next-day pilot query; it is not an expiry finding or an extrapolation to all later dates.

`original.xml` contains the exact LTI member from accepted observation `be688fe828a9bfa712680a2531fc619186b8b472ba60359bb12c6c2bf9df3f6b`. Each read binds it to the accepted catalog, independently compares its complete ordered body to the raw XML, qualifies the rendering, and checks all 29 literal list markers across eight lists. Current-corpus identity is corroboration only and cannot supply the output text.

`coverage.json` records the reviewed source scope, exact search expressions, observations, archive identities, 57-document publication-window metadata, assumptions and gaps. `coverage-index.jsonl.gz` preserves all 2,058 XML-member scan outcomes across both retained 2026 Lovtidend archives. Each read verifies every indexed identity against those accepted catalogs. The negative search finding is not a proof of all indirect legal effects.

`registry.json` separates the original's source-stated legal start, the accepted source-observation cutoff and the later interpretation-recording timestamp. Its exact digest is pinned in `reconstruction.py`. Omitted `--known-at` resolves to the maximum of the latest accepted source timestamp and this registered interpretation timestamp. Supplying that returned timestamp explicitly reproduces the same evidence and coverage. An earlier cutoff cannot use a later recorded interpretation. Newer unassessed accepted evidence prevents reuse of this coverage; an explicit older knowledge cutoff continues to select only evidence known by that cutoff.

Example:

```text
python -m law_history --repository . reconstruct forskrift/2026-09-10-1780 --legal-date 2026-09-22
```

Requests outside this window, unsupported documents and evidence/interpretation cutoffs before the required records return `UNAVAILABLE`, with specific gaps and no text. Changed evidence bindings are rejected. No current-text fallback, mutation of accepted products, or proposal promotion occurs.

The registered eligibility is **partial_source_based_baseline_only**. `full_legal_eligibility` remains false; no amendments are applied. The result concerns source text under the stated commencement and cited Husbankenloven §§ 1 and 10. It does not adjudicate comprehensive authority validity, individual grants, territorial applicability or all legal consequences, and it does not complete a general amendment engine.

Preserve this recorded method and its clock when introducing a later assessment. A future method needs its own explicit, source-bound record and supported interval; do not silently extend this one or overwrite its evidential meaning.
