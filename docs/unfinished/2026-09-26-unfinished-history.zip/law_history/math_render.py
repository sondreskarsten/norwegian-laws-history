"""Bounded offline TeX -> native MathML adapter (not body qualification).

Regeneration requires an installed Pandoc 3.10.1 executable. No package is
installed, downloaded or fetched by this module. Construct one renderer per
batch; it records the binary identity and refuses a changed executable.
"""
from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

CONTRACT = 'source-tex-native-mathml-pandoc-v1'
PANDOC_VERSION = '3.10.1'
PANDOC_API = [1, 23, 1, 2]
MATHML_NS = 'http://www.w3.org/1998/Math/MathML'
MAX_SOURCE_BYTES = 16_384
MAX_OUTPUT_BYTES = 262_144
MAX_NODES = 4096
MAX_DEPTH = 64
# Exact retained vocabulary, including escaped space and delimiter tokens.
_COMMANDS = set('text cdot frac lambda sum limits left right Delta begin end sqrt lgroup rgroup times int leq theta hspace displaystyle big qquad min equiv alpha Big geq bar gt in ge le log infty quad textbf sigma beta lbrace rbrace omega mathit lvert rvert Psi substack lbrack rbrack mathrm small div'.split()) | {':', '(', ')', '\\', '%', '{', '}', ',', ' '}
_ENVIRONMENTS = {'align', 'cases', 'bmatrix'}
_TOKENS = {'mi', 'mo', 'mn', 'mtext'}
_ARITY = {'mfrac': 2, 'msub': 2, 'msup': 2, 'mroot': 2, 'munder': 2, 'mover': 2, 'msubsup': 3, 'munderover': 3}
_ATTRIBUTES = {
    'math': {'display'}, 'semantics': set(), 'annotation': {'encoding'},
    'mi': {'mathvariant'}, 'mo': {'stretchy', 'form', 'mathvariant', 'accent', 'minsize', 'maxsize'},
    'mn': set(), 'mtext': {'mathvariant'}, 'mrow': set(), 'msqrt': set(),
    'mspace': {'width'}, 'mtable': set(), 'mtr': set(), 'mtd': {'columnalign', 'style'},
    **{tag: set() for tag in _ARITY},
}
_STYLES = {'text-align: center', 'text-align: left', 'text-align: right',
           'text-align: left; padding-left: 0', 'text-align: right; padding-right: 0'}


class MathRenderRejected(ValueError):
    def __init__(self, code: str, detail: str):
        self.code, self.detail = code, detail
        super().__init__(f'{code}: {detail}')


def _require(condition, code, detail):
    if not condition:
        raise MathRenderRejected(code, detail)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _source(text: str, role: str) -> tuple[str, str, list[str]]:
    _require(isinstance(text, str) and role in {'latexBlock', 'latexInline'}, 'invalid_source', 'Exact source text and supported role required')
    try:
        raw = text.encode('utf-8')
    except UnicodeError as exc:
        raise MathRenderRejected('invalid_source', 'Invalid Unicode source') from exc
    _require(0 < len(raw) <= MAX_SOURCE_BYTES and not any(ord(c) < 32 and c not in '\t\r\n' for c in text), 'source_limit', 'Unsupported control character or formula length')
    if text.startswith('$$') and text.endswith('$$') and len(text) > 4:
        mode, tex = 'block', text[2:-2]
    elif text.startswith('\\(') and text.endswith('\\)') and len(text) > 4:
        mode, tex = 'inline', text[2:-2]
    else:
        raise MathRenderRejected('unsupported_delimiters', 'Exact matching $$ or inline parenthesis delimiters required')
    _require(bool(tex.strip()), 'invalid_source', 'Empty formula')
    commands, depth, index = [], 0, 0
    text_starts, text_groups = set(), []
    while index < len(tex):
        c = tex[index]
        if c == '\\':
            match = re.match(r'\\([A-Za-z]+|[\s\S])', tex[index:])
            _require(match is not None, 'invalid_source', 'Trailing backslash')
            command = match.group(1)
            _require(command in _COMMANDS, 'unsupported_command', command)
            commands.append(command)
            index += len(match.group(0))
            if command == 'text':
                group = re.match(r'\s*\{', tex[index:])
                if group is not None:
                    text_starts.add(index + len(group.group(0)) - 1)
                else:
                    # Retained formulas also use the TeX single-token form
                    # \text m. Preserve it rather than inventing source braces.
                    _require(re.match(r'\s*[A-Za-z0-9]', tex[index:]) is not None,
                             'invalid_source', 'Text requires a group or single alphanumeric argument')
            if command in {'begin', 'end'}:
                environment = re.match(r'\{([^{}]+)\}', tex[index:])
                _require(environment is not None and environment.group(1) in _ENVIRONMENTS, 'unsupported_environment', 'Only observed align, cases and bmatrix environments are allowed')
            continue
        if c == '{':
            depth += 1
            if index in text_starts:
                text_groups.append([depth, False])
            _require(depth <= MAX_DEPTH, 'source_limit', 'Excessive source nesting')
        elif c == '}':
            if text_groups and text_groups[-1][0] == depth:
                _require(not text_groups[-1][1], 'invalid_source', 'Unclosed inline math in source text')
                text_groups.pop()
            depth -= 1
            _require(depth >= 0, 'invalid_source', 'Unbalanced source braces')
        if c == '$':
            _require(bool(text_groups), 'unsupported_source_token', 'Nested math delimiter outside source text')
            text_groups[-1][1] = not text_groups[-1][1]
        if c == '%':
            _require(bool(text_groups) and not text_groups[-1][1], 'unsupported_source_token', 'Unescaped comment marker outside literal source text')
        _require(c != '#', 'unsupported_source_token', 'Macro parameter marker is outside the source vocabulary')
        index += 1
    _require(depth == 0, 'invalid_source', 'Unbalanced source braces')
    return tex, mode, sorted(set(commands))


def validate_mathml(output: bytes, *, tex: str, display: str) -> str:
    """Validate the bounded Pandoc HTML fragment and return canonical MathML."""
    _require(isinstance(output, bytes) and 0 < len(output) <= MAX_OUTPUT_BYTES, 'output_limit', 'Missing or oversized renderer output')
    _require(not re.search(br'<!|<\?', output), 'unsafe_output', 'Declarations, entities, comments and processing instructions are forbidden')
    try:
        paragraph = ET.fromstring(output)
    except (ET.ParseError, ValueError) as exc:
        raise MathRenderRejected('invalid_mathml', 'Renderer output is not well-formed XML') from exc
    _require(paragraph.tag == 'p' and not paragraph.attrib and len(paragraph) == 1
             and not (paragraph.text or '').strip() and not (paragraph[0].tail or '').strip(),
             'invalid_mathml', 'Exactly one MathML expression in a plain paragraph is required')
    root = paragraph[0]
    _require(root.tag == '{' + MATHML_NS + '}math' and root.attrib == {'display': display}, 'invalid_mathml', 'MathML namespace or display mode differs')
    annotations, count = [], 0

    def visit(node, depth=0, parent=None):
        nonlocal count
        count += 1
        _require(count <= MAX_NODES and depth <= MAX_DEPTH, 'output_limit', 'Excessive MathML structure')
        _require(node.tag.startswith('{' + MATHML_NS + '}'), 'unsafe_output', 'Foreign output namespace')
        tag = node.tag.split('}', 1)[1]
        _require(tag in _ATTRIBUTES and not set(node.attrib) - _ATTRIBUTES.get(tag, set()), 'unsafe_output', 'Unsupported MathML element or attribute')
        required_parent = {'math': None, 'semantics': 'math', 'annotation': 'semantics', 'mtr': 'mtable', 'mtd': 'mtr'}
        if tag in required_parent:
            _require(parent == required_parent[tag], 'invalid_mathml', 'Misplaced MathML structural element')
        else:
            _require(parent in {'semantics', 'mrow', 'msqrt', 'mtd'} | set(_ARITY),
                     'invalid_mathml', 'Invalid MathML presentation parent')
        for key, value in node.attrib.items():
            valid = ((key == 'display' and value in {'block', 'inline'})
                or (key == 'encoding' and value == 'application/x-tex')
                or (key == 'mathvariant' and value in {'normal', 'italic', 'bold'})
                or (key in {'stretchy', 'accent'} and value in {'true', 'false'})
                or (key == 'form' and value in {'prefix', 'postfix'})
                or (key in {'minsize', 'maxsize'} and value in {'120%', '180%'})
                or (key == 'columnalign' and value in {'left', 'right', 'center'})
                or (key == 'style' and value in _STYLES)
                or (key == 'width' and bool(re.fullmatch(r'(?:[0-9]|[1-9][0-9])(?:\.[0-9]{1,3})?em', value))))
            _require(valid, 'unsafe_output', 'Unsupported MathML attribute value')
        children = list(node)
        if tag == 'annotation':
            _require(not children and node.attrib == {'encoding': 'application/x-tex'} and node.text == tex,
                     'source_binding_mismatch', 'MathML annotation differs from exact compiler input')
            annotations.append(node)
        elif tag in _TOKENS or tag == 'mspace':
            _require(not children and (tag != 'mspace' or not (node.text or '').strip()), 'invalid_mathml', 'Invalid token or spacing content')
        else:
            _require(not (node.text or '').strip() and all(not (c.tail or '').strip() for c in children), 'invalid_mathml', 'Text outside a MathML token')
            if tag == 'msqrt':
                _require(bool(children), 'invalid_mathml', 'Empty radical')
            if tag in _ARITY:
                _require(len(children) == _ARITY[tag], 'invalid_mathml', 'Wrong MathML operator arity')
            if tag == 'math':
                _require(len(children) == 1 and children[0].tag.endswith('}semantics'), 'invalid_mathml', 'One semantics container required')
            if tag == 'semantics':
                _require(len(children) == 2 and children[1].tag.endswith('}annotation') and not children[0].tag.endswith('}annotation'), 'invalid_mathml', 'Presentation and source annotation required')
            if tag in {'mtable', 'mtr'}:
                required = 'mtr' if tag == 'mtable' else 'mtd'
                _require(bool(children) and all(c.tag == '{' + MATHML_NS + '}' + required for c in children), 'invalid_mathml', 'Invalid MathML table topology')
        for child in children:
            visit(child, depth + 1, tag)

    def serialize(node, root=False):
        tag = node.tag.split('}', 1)[1]
        attributes = dict(node.attrib)
        if root:
            attributes['xmlns'] = MATHML_NS
        attrs = ''.join(f' {k}="{html.escape(v, quote=True)}"' for k, v in sorted(attributes.items()))
        return '<' + tag + attrs + '>' + html.escape(node.text or '') + ''.join(serialize(c) + html.escape(c.tail or '') for c in node) + '</' + tag + '>'

    visit(root)
    canonical = serialize(root, root=True)
    _require(len(annotations) == 1, 'source_binding_mismatch', 'Exactly one source annotation required')
    return canonical


class PandocMathRenderer:
    """One pinned local renderer, reused efficiently for a formula batch."""
    def __init__(self, executable: str | Path = 'pandoc', *, timeout_seconds: float = 10, expected_binary_sha256: str | None = None):
        _require(0 < timeout_seconds <= 60, 'invalid_runtime', 'Renderer timeout must be between zero and 60 seconds')
        _require(expected_binary_sha256 is None or bool(re.fullmatch(r'[0-9a-f]{64}', expected_binary_sha256)),
                 'invalid_runtime', 'Expected binary identity must be a SHA256')
        found = shutil.which(str(executable))
        _require(found is not None, 'missing_renderer', 'Install Pandoc 3.10.1 to regenerate formula products')
        self.executable = Path(found).resolve()
        self.timeout_seconds = timeout_seconds
        try:
            version = subprocess.run([str(self.executable), '--version'], capture_output=True, timeout=timeout_seconds, check=True)
            _require(version.stdout.splitlines()[0] == b'pandoc ' + PANDOC_VERSION.encode() and not version.stderr,
                     'renderer_version_mismatch', 'Exactly Pandoc 3.10.1 is required')
            self.binary_sha256 = _sha(self.executable.read_bytes())
            _require(expected_binary_sha256 is None or self.binary_sha256 == expected_binary_sha256,
                     'renderer_identity_mismatch', 'Executable does not match the required binary SHA256')
            self.fingerprint = (self.executable.stat().st_size, self.executable.stat().st_mtime_ns)
        except (OSError, subprocess.SubprocessError, IndexError) as exc:
            raise MathRenderRejected('renderer_unavailable', str(exc)) from exc

    def render(self, source_text: str, source_role: str) -> dict:
        tex, mode, commands = _source(source_text, source_role)
        _require((self.executable.stat().st_size, self.executable.stat().st_mtime_ns) == self.fingerprint,
                 'renderer_changed', 'Executable changed after identity verification')
        ast = {'pandoc-api-version': PANDOC_API, 'meta': {}, 'blocks': [
            {'t': 'Para', 'c': [{'t': 'Math', 'c': [{'t': 'DisplayMath' if mode == 'block' else 'InlineMath'}, tex]}]}]}
        try:
            result = subprocess.run([str(self.executable), '--from=json', '--to=html5', '--mathml', '--fail-if-warnings', '--sandbox'],
                                    input=json.dumps(ast, ensure_ascii=False).encode('utf-8'), capture_output=True, timeout=self.timeout_seconds)
        except (OSError, subprocess.SubprocessError) as exc:
            raise MathRenderRejected('renderer_failed', str(exc)) from exc
        _require(result.returncode == 0 and not result.stderr, 'renderer_rejected', result.stderr.decode('utf-8', errors='replace')[:4096] or 'Renderer exited unsuccessfully')
        mathml = validate_mathml(result.stdout, tex=tex, display=mode)
        renderer = {'name': 'pandoc', 'version': PANDOC_VERSION, 'executable_sha256': self.binary_sha256}
        return {'contract': CONTRACT, 'source_text': source_text, 'source_sha256': _sha(source_text.encode('utf-8')),
                'source_role': source_role, 'container_mode': 'block' if source_role == 'latexBlock' else 'inline',
                'delimiter_mode': mode, 'normalization': {'rule': 'remove-exact-outer-math-delimiters-v1', 'compiler_input': tex,
                    'compiler_input_sha256': _sha(tex.encode('utf-8'))}, 'commands': commands, 'renderer': renderer,
                'renderer_identity_sha256': _sha(json.dumps(renderer, sort_keys=True, separators=(',', ':')).encode()),
                'mathml': mathml, 'mathml_sha256': _sha(mathml.encode('utf-8'))}
