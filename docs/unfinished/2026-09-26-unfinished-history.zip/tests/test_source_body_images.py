"""Exact retained image source bindings and post-render tampering checks."""
import hashlib
import json
from pathlib import Path
import unittest
from law_history import source_body_gate as gate
from test_source_body_lists import captured

FIXTURES = Path(__file__).parent / 'fixtures/source_body'


class SourceImageTests(unittest.TestCase):
    def test_retained_sources_require_preserved_assets_and_reverse_exactly(self):
        rows = json.loads((FIXTURES/'images-source-members.json').read_text(encoding='utf-8'))
        acquired = json.loads((FIXTURES/'images-acquisition-records.json').read_text(encoding='utf-8'))
        for row in rows:
            with self.subTest(refid=row['refid']):
                raw = (FIXTURES/row['retained_file']).read_bytes()
                self.assertEqual(hashlib.sha256(raw).hexdigest(), row['member_sha256'])
                model = captured(raw)
                args = dict(expected_refid=row['refid'], expected_member_sha256=row['member_sha256'],
                            source_occurrence_id=row['source_occurrence_id'])
                missing = gate.qualify_source_body(raw, model, **args)
                self.assertEqual(missing['report']['reasons'][0]['code'], 'missing_source_asset')
                bound = {}

                def resolve(src, *, source_use):
                    evidence = acquired[src]
                    self.assertEqual(source_use['member_sha256'], row['member_sha256'])
                    self.assertEqual(source_use['refid'], row['refid'])
                    extension = Path(evidence['path']).suffix
                    descriptor = {'sha256': evidence['sha256'], 'path': 'assets/'+evidence['sha256']+extension}
                    bound[src] = descriptor
                    return descriptor

                result = gate.qualify_source_body(raw, model, asset_resolver=resolve, **args)
                self.assertEqual(result['report']['status'], 'passed', result['report'])
                self.assertTrue(result['report']['assets'])
                gate.verify_rendered_body(result['html'], model, stylesheet=result['stylesheet'], assets=bound)
                image = next(iter(bound.values()))
                for before, after in (('../'+image['path'], 'https://lovdata.no/live.png'),
                        ('data-source-body-src=', 'data-changed-src=')):
                    changed = result['html'].replace(before, after, 1)
                    self.assertNotEqual(changed, result['html'])
                    with self.assertRaises(gate.BodyRejected):
                        gate.verify_rendered_body(changed, model, stylesheet=result['stylesheet'], assets=bound)

    def test_missing_acquisition_and_path_injection_never_expose_html(self):
        row = json.loads((FIXTURES/'images-source-members.json').read_text(encoding='utf-8'))[0]
        raw = (FIXTURES/row['retained_file']).read_bytes()
        for resolver in (lambda *a, **kw: {'sha256': 'a'*64, 'path': '../outside.png'},
                         lambda *a, **kw: {'sha256': 'a'*64, 'path': 'assets/not-a-hash.png'}):
            result = gate.qualify_source_body(raw, captured(raw), expected_refid=row['refid'],
                expected_member_sha256=row['member_sha256'], source_occurrence_id=row['source_occurrence_id'],
                asset_resolver=resolver)
            self.assertEqual(result['report']['status'], 'rejected')
            self.assertIsNone(result['html'])
