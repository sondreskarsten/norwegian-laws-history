"""Offline adapter checks; runtime cases state the exact Pandoc prerequisite."""
import hashlib
import subprocess
import unittest
from unittest.mock import patch
from law_history.math_render import (
    MathRenderRejected, PandocMathRenderer, _source, validate_mathml, MATHML_NS,
)


class MathMLBoundaryTests(unittest.TestCase):
    def fragment(self, expression='<msup><mi>x</mi><mn>2</mn></msup>', source='x^2'):
        return (f'<p><math xmlns="{MATHML_NS}" display="inline"><semantics>{expression}'
                f'<annotation encoding="application/x-tex">{source}</annotation></semantics></math></p>').encode()

    def test_bounded_mathml_is_canonical_and_source_bound(self):
        rendered = validate_mathml(self.fragment(), tex='x^2', display='inline')
        self.assertTrue(rendered.startswith('<math display="inline" xmlns='))
        self.assertIn('<msup><mi>x</mi><mn>2</mn></msup>', rendered)
        with self.assertRaises(MathRenderRejected) as error:
            validate_mathml(self.fragment(source='x^3'), tex='x^2', display='inline')
        self.assertEqual(error.exception.code, 'source_binding_mismatch')

    def test_unsafe_or_invalid_output_never_becomes_mathml(self):
        examples = [
            self.fragment('<script>alert(1)</script>'),
            self.fragment('<mi href="https://example.com">x</mi>'),
            self.fragment('<mi xmlns="http://www.w3.org/1999/xhtml">x</mi>'),
            self.fragment('<mtd style="background:url(https://example.com)"><mi>x</mi></mtd>'),
            self.fragment('<mtd><mi>x</mi></mtd>'),
            self.fragment('<mfrac><mi>x</mi></mfrac>'),
            self.fragment('<merror><mtext>failed</mtext></merror>'),
            b'<!DOCTYPE p [<!ENTITY x SYSTEM "file:///private">]>' + self.fragment(),
            self.fragment().replace(b'</p>', b'<span>extra</span></p>'),
            self.fragment().replace(b'<mi>x</mi>', b'<!-- omitted --><mi>x</mi>'),
        ]
        for output in examples:
            with self.subTest(output=output), self.assertRaises(MathRenderRejected):
                validate_mathml(output, tex='x^2', display='inline')

    def test_unknown_commands_environments_and_malformed_sources_fail_first(self):
        for tex in (r'$$\input{secret}$$', r'$$\href{https://example.com}{x}$$',
                    r'$$\begin{unknown}x\end{unknown}$$', r'$$x^{2$$',
                    '$$x%comment$$', '$$x#1$$', '$$x$y$$', '$$x\\$$', r'$$\text{x $a%comment$}$$',
                    '$$' + '{' * 65 + 'x' + '}' * 65 + '$$'):
            with self.subTest(tex=tex), self.assertRaises(MathRenderRejected):
                _source(tex, 'latexBlock')
        self.assertEqual(_source(r'$$\{x\}\ \%$$', 'latexInline')[1], 'block')


class InstalledPandocMathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.renderer = PandocMathRenderer()
        except MathRenderRejected as exc:
            if exc.code in {'missing_renderer', 'renderer_unavailable', 'renderer_version_mismatch'}:
                raise unittest.SkipTest('Runtime acceptance requires installed Pandoc 3.10.1: ' + str(exc))
            raise

    def test_real_fraction_greek_and_annotation_provenance(self):
        # Retained forskrift/1990-01-25-92, source formula inventory index 0.
        source = r'$$ y=\frac{(a+17 \Psi)C}{1000}+2 $$'
        result = self.renderer.render(source, 'latexBlock')
        self.assertEqual(result['source_text'], source)
        self.assertEqual(result['source_sha256'], hashlib.sha256(source.encode()).hexdigest())
        self.assertEqual(result['normalization']['compiler_input'], source[2:-2])
        self.assertEqual(result['renderer']['version'], '3.10.1')
        self.assertEqual(len(result['renderer']['executable_sha256']), 64)
        self.assertIn('<mfrac>', result['mathml'])
        self.assertIn('Ψ', result['mathml'])
        self.assertEqual(result['mathml_sha256'], self.renderer.render(source, 'latexBlock')['mathml_sha256'])

    def test_source_container_and_delimiter_mode_are_not_conflated(self):
        # Retained inline formula in forskrift/1990-01-25-92 uses $$.
        result = self.renderer.render(r'$$\frac{54}{L^{2}}$$', 'latexInline')
        self.assertEqual((result['container_mode'], result['delimiter_mode']), ('inline', 'block'))
        # Retained block formula in forskrift/2004-04-01-611 uses inline delimiters.
        source = r'\(\text{Standardisert erstatning} = \sum\limits_{n=0}^{150} (S-tn)\)'
        result = self.renderer.render(source, 'latexBlock')
        self.assertEqual((result['container_mode'], result['delimiter_mode']), ('block', 'inline'))
        self.assertIn('Standardisert erstatning', result['mathml'])

    def test_align_cases_and_matrix_remain_native_structures(self):
        for source in (r'$$\begin{align}x&=1\\y&=2\end{align}$$',
                       r'$$\begin{cases}x&x>0\\0&x\leq0\end{cases}$$',
                       r'$$\begin{bmatrix}1&2\\3&4\end{bmatrix}$$'):
            with self.subTest(source=source):
                self.assertIn('<mtable>', self.renderer.render(source, 'latexBlock')['mathml'])

    def test_literal_percentage_and_embedded_math_in_source_text(self):
        # Both forms occur in the retained source inventory; percent is text,
        # while dollar-delimited variables inside text remain mathematical.
        result = self.renderer.render(r'$$R_{\text{12 %}}$$', 'latexBlock')
        self.assertIn('12 %</mtext>', result['mathml'])
        single = self.renderer.render(r'$$\text m$$', 'latexBlock')
        self.assertIn('>m</mtext>', single['mathml'])
        result = self.renderer.render(r'$$\text{når $P_1$ er større enn $P$}$$', 'latexBlock')
        self.assertIn('<msub><mi>P</mi><mn>1</mn></msub>', result['mathml'])
        with self.assertRaises(MathRenderRejected) as error:
            PandocMathRenderer(expected_binary_sha256='0' * 64)
        self.assertEqual(error.exception.code, 'renderer_identity_mismatch')

    def test_known_parser_gaps_fail_without_stripping_source_commands(self):
        # These formatting forms occur in the five rejected retained formulas.
        for source in (r'$$x\hspace{3mm}y$$', r'$$\small x$$'):
            with self.subTest(source=source), self.assertRaises(MathRenderRejected) as error:
                self.renderer.render(source, 'latexBlock')
            self.assertEqual(error.exception.code, 'renderer_rejected')

    def test_warning_or_bad_version_is_never_accepted(self):
        with patch('law_history.math_render.subprocess.run', return_value=subprocess.CompletedProcess([], 0, b'<p/>', b'warning')):
            with self.assertRaises(MathRenderRejected) as error:
                self.renderer.render(r'\(x\)', 'latexInline')
            self.assertEqual(error.exception.code, 'renderer_rejected')
        with patch('law_history.math_render.subprocess.run', return_value=subprocess.CompletedProcess([], 0, b'pandoc 0.0\n', b'')):
            with self.assertRaises(MathRenderRejected) as error:
                PandocMathRenderer()
            self.assertEqual(error.exception.code, 'renderer_version_mismatch')
