"""Used-only raster dependencies, byte readback and historical product clocks."""
from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from law_history import source_body_products as products
from law_history.ledger import ingest
from law_history.validation import canonical, file_hash
from test_body_assets import acquisition, FIXTURES
from test_source_body_products import small_xml, source_fixture


def image_xml(refid="lov/2024-01-01-1", src="/static/source.png", suffix=""):
    return small_xml(refid, content=f'<img src="{src}" alt="Retained source image"/>{suffix}')


class SourceBodyMediaProductTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="body-media-test-")
        self.root = Path(self.temporary.name)
        self.repository = self.root / "ledger"
        self.number = 0
        self.addCleanup(self.temporary.cleanup)

    def accept(self, documents, observed="2026-09-25T12:00:00+00:00"):
        self.number += 1
        path, receipt, _ = source_fixture(self.root / f"source-{self.number}", documents, observed=observed)
        ingest(str(path), self.repository)
        return receipt["observation_id"]

    def assets(self, *, retrieved=None):
        self.number += 1
        directory = self.root / f"media-{self.number}"
        directory.mkdir()
        receipt, bundle, rows = acquisition(directory)
        if retrieved is not None:
            rows[0]["retrieved_at"] = retrieved
            receipt, bundle, rows = acquisition(directory, rows=rows)
        return receipt, bundle

    def build(self, observation, receipt, bundle):
        return products.qualify_bodies(self.repository, observation, asset_receipt=receipt, asset_bundle=bundle)

    def rows(self, receipt, name="inventory.jsonl.gz"):
        return list(products._rows(products.artifact_tree(self.repository, receipt) / name))

    def forged_receipt(self, original, change):
        receipt = deepcopy(original)
        receipt.pop("status", None)
        change(receipt)
        core = {k: v for k, v in receipt.items() if k not in {"body_product_id", "release_tag"}}
        core["bundle"] = {k: v for k, v in core["bundle"].items() if k != "url"}
        identity = hashlib.sha256(canonical(core, newline=True)).hexdigest()
        receipt.update(body_product_id=identity, release_tag="bodies-" + identity)
        receipt["bundle"]["url"] = f'https://github.com/{receipt["repository"]}/releases/download/{receipt["release_tag"]}/bodies.tar.gz'
        repository = self.root / ("forged-" + identity)
        destination = repository / "body-products" / identity
        destination.mkdir(parents=True)
        (destination / "receipt.json").write_bytes(canonical(receipt, newline=True))
        return repository, identity

    def test_used_passed_assets_only_with_independent_binary_readback(self):
        # The rejected document resolves a later GIF before its missing second
        # image fails. Neither that GIF nor its later clock may leak into output.
        failed = image_xml("lov/2024-01-01-2", "/static/source.gif",
                           '<img src="/static/missing.png" alt="Missing"/>')
        observation = self.accept([image_xml(), failed, small_xml("lov/2024-01-01-3")])
        acquisition_receipt, bundle = self.assets()
        receipt = self.build(observation, acquisition_receipt, bundle)
        self.assertEqual(receipt["contract"], products.MEDIA_CONTRACT)
        self.assertEqual(receipt["counts"], {"selected": 3, "laws": 3, "forskrifter": 0, "passed": 2, "rejected": 1})
        self.assertEqual(receipt["source_knowledge_cutoff"], "2026-09-25T12:00:00+00:00")
        self.assertEqual(receipt["knowledge_cutoff"], "2026-09-26T11:00:00+02:00")
        dependency = receipt["media_dependencies"]
        self.assertEqual(dependency["acquisition_receipt"], acquisition_receipt)
        self.assertEqual(len(dependency["assets"]), 1)
        asset = dependency["assets"][0]
        self.assertTrue(asset["path"].endswith(".png"))
        self.assertEqual(asset["source_uses"][0]["caller_source_use"]["refid"], "lov/2024-01-01-1")
        tree = products.artifact_tree(self.repository, receipt)
        self.assertEqual((tree / asset["path"]).read_bytes(), (FIXTURES / "source.png").read_bytes())
        self.assertEqual(receipt["artifact_hashes"][asset["path"]], file_hash(tree / asset["path"]))
        inventory = self.rows(receipt)
        rejected = next(r for r in inventory if r["refid"] == "lov/2024-01-01-2")
        self.assertEqual(rejected["status"], "rejected")
        self.assertIsNone(rejected["payload"])
        documents = [doc for shard in receipt["shards"] for doc in self.rows(receipt, shard)]
        self.assertIn('../' + asset["path"], next(d for d in documents if d["refid"].endswith("-1"))["html"])
        rebuilt = products.read_body_product(self.repository, receipt["body_product_id"], asset_bundle=bundle)
        self.assertEqual(rebuilt["media_dependencies"], dependency)
        self.assertEqual(rebuilt["legal_valid_time"], products.LEGAL)

    def test_v1_receipts_remain_unchanged_and_media_upgrade_is_explicit(self):
        observation = self.accept([image_xml(), small_xml("lov/2024-01-01-2")])
        v1 = products.qualify_bodies(self.repository, observation)
        retained = (self.repository / "body-products" / v1["body_product_id"] / "receipt.json").read_bytes()
        self.assertEqual(v1["contract"], products.CONTRACT)
        self.assertNotIn("media_dependencies", v1)
        self.assertNotIn("source_knowledge_cutoff", v1)
        self.assertEqual(v1["counts"]["rejected"], 1)
        receipt, bundle = self.assets()
        v2 = self.build(observation, receipt, bundle)
        self.assertEqual(v2["counts"]["passed"], 2)
        self.assertEqual(v2["comparison_product_id"], v1["body_product_id"])
        self.assertEqual(v2["parent_body_product_id"], v1["body_product_id"])
        self.assertEqual(retained, (self.repository / "body-products" / v1["body_product_id"] / "receipt.json").read_bytes())
        self.assertEqual(products.read_body_product(self.repository, v1["body_product_id"])["counts"], v1["counts"])

    def test_newer_asset_knowledge_never_leaks_into_historical_comparisons(self):
        first_observation = self.accept([image_xml(), small_xml("lov/2024-01-01-2")])
        first = products.qualify_bodies(self.repository, first_observation)
        future_receipt, future_bundle = self.assets(retrieved="2026-09-28T00:00:00Z")
        future = self.build(first_observation, future_receipt, future_bundle)
        second_observation = self.accept([image_xml(), small_xml("lov/2024-01-01-2", content="Later XML.")],
                                         "2026-09-26T12:00:00+00:00")
        historical_v1 = products.qualify_bodies(self.repository, second_observation)
        self.assertEqual(historical_v1["parent_body_product_id"], future["body_product_id"])
        self.assertEqual(historical_v1["comparison_product_id"], first["body_product_id"])
        earlier_receipt, earlier_bundle = self.assets(retrieved="2026-09-26T11:00:00Z")
        historical_v2 = self.build(second_observation, earlier_receipt, earlier_bundle)
        self.assertEqual(historical_v2["comparison_product_id"], historical_v1["body_product_id"])
        self.assertEqual(historical_v2["knowledge_cutoff"], "2026-09-26T12:00:00+00:00")
        self.assertNotEqual(historical_v2["comparison_product_id"], future["body_product_id"])

    def test_no_used_dependency_does_not_create_empty_v2(self):
        receipt, bundle = self.assets()
        for documents in ([small_xml()], [image_xml(src="/static/missing.png")]):
            observation = self.accept(documents)
            with self.assertRaisesRegex(ValueError, "No passed bodies used"):
                self.build(observation, receipt, bundle)
        self.assertEqual(products.body_products(self.repository, verify=False), [])
        with self.assertRaisesRegex(ValueError, "requires its exact"):
            products.qualify_bodies(self.repository, observation, asset_bundle=bundle)

    def test_replay_binds_exact_acquisition_and_generator_sources(self):
        observation = self.accept([image_xml()])
        acquisition_receipt, bundle = self.assets()
        receipt = self.build(observation, acquisition_receipt, bundle)
        generator = receipt["generator"]
        self.assertTrue({"body_assets.py", "primary_sources.py"} <= set(generator["sources"]))
        self.assertEqual(generator["media_acquisition"]["observation_id"], acquisition_receipt["observation_id"])
        with patch.object(products, "_input", side_effect=AssertionError("unexpected source replay")):
            replay = products.qualify_bodies(self.repository, observation, asset_receipt=acquisition_receipt,
                                            asset_bundle=bundle, verify_replay=False)
            self.assertEqual(replay["status"], "already_present")
            self.assertEqual(replay["body_product_id"], receipt["body_product_id"])
            self.assertEqual(products.qualify_all(self.repository)[0]["body_product_id"], receipt["body_product_id"])
        changed = deepcopy(acquisition_receipt)
        changed["bundle"]["url"] = "https://other.test/snapshot.tar.gz"
        with self.assertRaisesRegex(ValueError, "identity changed"):
            self.build(observation, changed, bundle)

    def test_binary_tampering_rejected_by_membership_and_independent_audit(self):
        observation = self.accept([image_xml()])
        acquisition_receipt, bundle = self.assets()
        receipt = self.build(observation, acquisition_receipt, bundle)
        tree = products.artifact_tree(self.repository, receipt)
        asset = receipt["media_dependencies"]["assets"][0]
        (tree / asset["path"]).write_bytes(b"not the acquired binary")
        with self.assertRaisesRegex(ValueError, "bytes changed"):
            products.read_body_product(self.repository, receipt["body_product_id"])
        with products._input(self.repository, observation) as source:
            with self.assertRaisesRegex(ValueError, "binary asset differs"):
                products._audit(source, receipt, tree, {}, asset_bundle=bundle)

    def test_reidentified_wrong_clock_and_asset_descriptor_fail_closed(self):
        observation = self.accept([image_xml()])
        acquisition_receipt, bundle = self.assets()
        receipt = self.build(observation, acquisition_receipt, bundle)
        forged, identity = self.forged_receipt(receipt, lambda r: r.update(knowledge_cutoff=r["source_knowledge_cutoff"]))
        with self.assertRaisesRegex(ValueError, "clock differs"):
            products.read_body_receipt(forged, identity)
        def altered(r):
            r["media_dependencies"]["assets"][0]["source_uses"][0]["caller_source_use"]["refid"] = "lov/invented"
        forged, identity = self.forged_receipt(receipt, altered)
        with self.assertRaisesRegex(ValueError, "dependencies differ"):
            products.read_body_product(forged, identity, ledger_repository=self.repository,
                artifacts=products.artifact_tree(self.repository, receipt), asset_bundle=bundle)


if __name__ == "__main__":
    unittest.main()
