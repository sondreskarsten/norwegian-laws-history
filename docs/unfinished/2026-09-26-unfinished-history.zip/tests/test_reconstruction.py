"""Boundary and tamper checks for the actual retained original pilot evidence."""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from law_history import reconstruction as reconstruction
from law_history.__main__ import main
from law_history.ledger import list_observations, read_observation
from law_history.validation import canonical, read_json

REPOSITORY = Path(__file__).resolve().parents[1]
REFID = "forskrift/2026-09-10-1780"


class ReconstructionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root, cls.registry, cls.coverage, _ = reconstruction._method(REFID)
        # Verify the real ledger once. Individual cases change only the inputs
        # named in their assertion, without fetching source bundles or networks.
        cls.accepted = [summary for summary in list_observations(REPOSITORY)
                        if summary["observation_id"] in cls.registry["assessed_observations"]]
        cls.records = {identity: read_observation(REPOSITORY, identity)
                       for identity in cls.coverage["evidence_observations"]}

    def setUp(self):
        self.accepted_patch = patch.object(reconstruction, "list_observations", return_value=copy.deepcopy(self.accepted))
        self.catalog_patch = patch.object(reconstruction, "read_observation", side_effect=lambda _, identity: self.records[identity])
        self.accepted_mock = self.accepted_patch.start()
        self.catalog_mock = self.catalog_patch.start()
        self.addCleanup(self.accepted_patch.stop)
        self.addCleanup(self.catalog_patch.stop)

    def read(self, day="2026-09-22", cutoff=None, refid=REFID):
        return reconstruction.reconstruct(REPOSITORY, refid, day, cutoff)

    def codes(self, result):
        return {gap["code"] for gap in result["gaps"]}

    def test_before_on_after_commencement_and_window_end(self):
        for day, status in (("2026-09-20", "UNAVAILABLE"), ("2026-09-21", "PARTIAL"),
                            ("2026-09-22", "PARTIAL"), ("2026-09-23", "UNAVAILABLE")):
            with self.subTest(day=day):
                result = self.read(day)
                self.assertEqual(result["status"], status)
                self.assertFalse(result["full_legal_eligibility"])
                self.assertEqual(result["applied_operations"], [])
                if status == "PARTIAL":
                    self.assertTrue(result["partial_baseline_eligible"])
                    self.assertEqual(result["baseline"]["role"], "amendment_acts")
                else:
                    self.assertIsNone(result["document"])
                    self.assertIsNone(result["baseline"])
                    self.assertIn("outside_supported_pilot_window", self.codes(result))
        self.assertIn("before_source_commencement", self.codes(self.read("2026-09-20")))

    def test_original_and_all_literal_markers_are_qualified(self):
        result = self.read()
        document = result["document"]
        self.assertEqual(result["baseline"]["member_sha256"], self.registry["baseline"]["member_sha256"])
        self.assertEqual(document["literal_list_marker_count"], 29)
        self.assertEqual(document["qualification"]["element_counts"]["li"], 29)
        self.assertEqual(document["qualification"]["element_counts"]["ul"], 8)
        self.assertEqual(document["qualification"]["rendered_reverse_check"], "passed")
        self.assertEqual(document["source_body_html"].count("data-li-identifier="), 29)
        self.assertIn("LTI/forskrift/2026-09-10-1780", document["source_body_html"])
        self.assertEqual(result["coverage"]["verified_xml_occurrences"], 2058)
        self.assertEqual(result["coverage"]["applied_operations"], [])
        self.assertIn("partial_scope_limit", self.codes(result))

    def test_default_resolved_cutoff_reproduces_explicit_coverage_and_result(self):
        default = self.read()
        self.assertEqual(default["resolved_known_at"], self.registry["interpretation_recorded_at"])
        explicit = self.read(cutoff=default["resolved_known_at"])
        self.assertEqual(default["coverage"], explicit["coverage"])
        self.assertEqual(default["document"], explicit["document"])
        default.pop("requested_known_at")
        explicit.pop("requested_known_at")
        self.assertEqual(default, explicit)
        self.assertNotEqual(default["source_knowledge_cutoff"], default["interpretation_recorded_at"])

    def test_earlier_source_and_interpretation_cutoffs_are_distinct_gaps(self):
        earlier = self.read(cutoff="2026-09-25T00:00:00Z")
        self.assertEqual(earlier["status"], "UNAVAILABLE")
        self.assertIn("source_evidence_not_known_at_cutoff", self.codes(earlier))
        self.assertIn("interpretation_not_recorded_at_cutoff", self.codes(earlier))
        for later_evidence in ("commencement", "cited_source_basis", "supported_pilot_window", "method_id"):
            self.assertNotIn(later_evidence, earlier)
        source_known = self.read(cutoff=self.registry["source_knowledge_cutoff"])
        self.assertIn("interpretation_not_recorded_at_cutoff", self.codes(source_known))
        self.assertNotIn("source_evidence_not_known_at_cutoff", self.codes(source_known))
        self.assertIsNone(source_known["document"])

    def test_newer_unassessed_evidence_prevents_stale_default_but_not_earlier_cutoff(self):
        original = self.read()
        newer = copy.deepcopy(self.accepted[-1])
        newer.update(observation_id="f" * 64, catalog_sha256="a" * 64, knowledge_cutoff="2026-09-27T00:00:00Z")
        self.accepted_mock.return_value = [*self.accepted, newer]
        unavailable = self.read()
        self.assertEqual(unavailable["status"], "UNAVAILABLE")
        self.assertIn("unassessed_accepted_source_evidence", self.codes(unavailable))
        self.assertIsNone(unavailable["document"])
        self.assertEqual(unavailable["resolved_known_at"], newer["knowledge_cutoff"][:-1] + "+00:00")
        repeated = self.read(cutoff=unavailable["resolved_known_at"])
        self.assertEqual(unavailable["gaps"], repeated["gaps"])
        historical = self.read(cutoff=original["resolved_known_at"])
        self.assertEqual(historical["status"], "PARTIAL")
        self.assertEqual(historical["coverage"], original["coverage"])

    def test_identical_complete_catalog_does_not_invent_new_evidence_or_extend_window(self):
        newer = copy.deepcopy(self.accepted[-1])
        newer.update(observation_id="f" * 64, knowledge_cutoff="2026-09-27T00:00:00Z")
        self.accepted_mock.return_value = [*self.accepted, newer]
        result = self.read()
        self.assertEqual(result["status"], "PARTIAL")
        self.assertEqual(result["coverage"]["equivalent_catalog_observations"][0]["observation_id"], newer["observation_id"])
        self.assertEqual(self.read("2026-09-23")["status"], "UNAVAILABLE")

    def test_missing_required_observation_and_unknown_source_clock(self):
        identity = self.registry["baseline"]["observation_id"]
        self.accepted_mock.return_value = [s for s in self.accepted if s["observation_id"] != identity]
        self.assertIn("required_observation_unavailable", self.codes(self.read()))
        unknown = copy.deepcopy(self.accepted[-1])
        unknown.update(observation_id="e" * 64, knowledge_cutoff=None)
        self.accepted_mock.return_value = [*self.accepted, unknown]
        self.assertIn("unassessed_source_time", self.codes(self.read()))

    def test_unsupported_document_never_falls_back_to_current_text(self):
        result = self.read(refid="forskrift/2022-09-02-1529")
        self.assertEqual(result["status"], "UNAVAILABLE")
        self.assertIn("unsupported_document", self.codes(result))
        self.assertIsNone(result["document"])
        self.catalog_mock.assert_not_called()

    def test_changed_accepted_member_and_observation_bindings_fail_closed(self):
        identity = self.registry["baseline"]["observation_id"]
        changed = copy.deepcopy(self.records[identity])
        row = next(r for r in changed[2] if r["source_occurrence_id"] == self.registry["baseline"]["source_occurrence_id"])
        row["member_sha256"] = "0" * 64
        self.catalog_mock.side_effect = lambda _, obs: changed if obs == identity else self.records[obs]
        with self.assertRaisesRegex(ValueError, "baseline.*binding changed"):
            self.read()
        self.catalog_mock.side_effect = lambda _, obs: self.records[obs]
        changed_summary = copy.deepcopy(self.accepted)
        changed_summary[0]["catalog_sha256"] = "0" * 64
        self.accepted_mock.return_value = changed_summary
        with self.assertRaisesRegex(ValueError, "Assessed observation binding changed"):
            self.read()

    def test_raw_coverage_and_registry_tampering_are_rejected(self):
        for name in ("original.xml", "coverage.json", "coverage-index.jsonl.gz", "registry.json"):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp:
                parent = Path(temp)
                copied = parent / self.root.name
                shutil.copytree(self.root, copied)
                with (copied / name).open("ab") as stream:
                    stream.write(b" ")
                with patch.object(reconstruction, "REGISTRY_DIRECTORY", parent):
                    with self.assertRaisesRegex(ValueError, "binding changed"):
                        self.read()

    def test_rehashed_registry_cannot_substitute_current_source_as_baseline(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp); copied = parent / self.root.name
            shutil.copytree(self.root, copied)
            registry = read_json(copied / "registry.json")
            registry["baseline"].update({key: registry["current_corroboration"][key]
                                        for key in reconstruction.CATALOG_FIELDS})
            (copied / "registry.json").write_bytes(canonical(registry, newline=True))
            changed_hash = hashlib.sha256((copied / "registry.json").read_bytes()).hexdigest()
            with patch.object(reconstruction, "REGISTRY_DIRECTORY", parent), patch.dict(
                    reconstruction.METHODS, {REFID: (copied.name, changed_hash)}):
                with self.assertRaisesRegex(ValueError, "Baseline must be original"):
                    self.read()

    def test_invalid_dates_and_timezone_free_cutoffs_are_rejected(self):
        for day in ("2026-9-22", "2026-09-31", "2026-09-22T00:00:00Z"):
            with self.subTest(day=day), self.assertRaises(ValueError):
                self.read(day)
        with self.assertRaisesRegex(ValueError, "timezone"):
            self.read(cutoff="2026-09-26T12:00:00")

    def test_cli_uses_same_partial_result_and_concrete_unavailable_json(self):
        for refid, status in ((REFID, "PARTIAL"), ("lov/2020-12-18-146", "UNAVAILABLE")):
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                code = main(["--repository", str(REPOSITORY), "reconstruct", refid,
                             "--legal-date", "2026-09-22"])
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(output.getvalue())["status"], status)


if __name__ == "__main__":
    unittest.main()
