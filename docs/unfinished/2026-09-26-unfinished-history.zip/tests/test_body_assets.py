import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

from law_history.body_assets import BodyAssetAdapter, _media
from law_history.primary_sources import CONTRACT, _encoded

FIXTURES = Path(__file__).parent / 'fixtures/body_assets'


def acquisition(root, *, rows=None, content=None):
    content = content or {'source.png': (FIXTURES/'source.png').read_bytes(),
                          'source.gif': (FIXTURES/'source.gif').read_bytes()}
    if rows is None:
        rows = [{'url': 'https://lovdata.no/static/'+name, 'path': name,
                 'retrieved_at': '2026-09-26T11:00:00+02:00' if name.endswith('png') else '2026-09-26T10:00:00+00:00',
                 'status': 200, 'content_type': 'image/'+name.split('.')[-1],
                 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                 'source_uses': [{'unverified_manifest_assertion': 'never trusted as XML binding'}]}
                for name, data in content.items()]
    manifest = _encoded(rows); bundle = root/'snapshot.tar.gz'
    with tarfile.open(bundle, 'w:gz') as archive:
        for name, data in [('manifest.json', manifest), *content.items()]:
            info = tarfile.TarInfo(name); info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
    receipt = {'version': 1, 'contract': CONTRACT, 'repository': 'example/evidence', 'source_sha': 'a'*40,
        'snapshot_manifest_sha256': hashlib.sha256(manifest).hexdigest(), 'member_count': len(content)+1,
        'acquired_sources': len(content), 'failed_attempts': len(rows)-len(content),
        'bundle': {'name': 'snapshot.tar.gz', 'bytes': bundle.stat().st_size,
                   'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest()}}
    identity = hashlib.sha256(_encoded(receipt)).hexdigest()
    receipt.update(observation_id=identity, release_tag='primary-source-'+identity)
    base = 'https://github.com/example/evidence/releases/download/primary-source-'+identity+'/'
    receipt['receipt_url'] = base+'evidence.json'; receipt['bundle']['url'] = base+'snapshot.tar.gz'
    return receipt, bundle, rows


class BodyAssetTests(unittest.TestCase):
    def test_exact_url_binding_clocks_used_only_export_and_replay(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); receipt, bundle, _ = acquisition(root)
            adapter = BodyAssetAdapter(receipt, bundle)
            self.assertIsNone(adapter.knowledge_cutoff)
            source_use = {'refid': 'lov/example', 'path': '/main[1]/img[1]'}
            descriptor = adapter.resolve('static/source.png', source_use=source_use)
            self.assertEqual(descriptor['knowledge_cutoff'], '2026-09-26T11:00:00+02:00')
            self.assertIn('requires_independent', descriptor['source_association'])
            self.assertEqual(descriptor['path'], 'assets/'+descriptor['sha256']+'.png')
            descriptor['sha256'] = 'changed'; source_use['refid'] = 'changed'
            exported = adapter.export_used(root/'out')
            self.assertEqual(len(list((root/'out/assets').iterdir())), 1)
            self.assertEqual(exported, adapter.export_used(root/'out'))
            self.assertEqual(exported['assets'][0]['source_uses'][0]['caller_source_use']['refid'], 'lov/example')
            adapter.resolve('/static/source.gif', source_use={'path': '/main[1]/img[2]'})
            self.assertEqual(adapter.knowledge_cutoff, '2026-09-26T10:00:00+00:00')
            target = root/'out'/exported['assets'][0]['path']; target.write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError, 'refusing overwrite'): adapter.export_used(root/'out')

    def test_ambiguity_failed_partial_wrong_media_and_changed_bundle(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); receipt, bundle, rows = acquisition(root)
            for change in ('duplicate', 'failed', 'partial', 'redirect'):
                altered = copy.deepcopy(rows)
                if change == 'duplicate':
                    altered.append({'url': rows[0]['url'], 'retrieved_at': rows[0]['retrieved_at'], 'error': 'another attempt'})
                elif change == 'failed':
                    altered[0]['error'] = 'partial transfer'
                elif change == 'partial': altered[0]['content_range'] = 'bytes 0-10/100'
                else: altered[0]['final_url'] = 'https://lovdata.no/static/other.png'
                receipt, bundle, _ = acquisition(root, rows=altered)
                adapter = BodyAssetAdapter(receipt, bundle)
                with self.subTest(change=change), self.assertRaises(ValueError):
                    adapter.resolve('static/source.png', source_use={'path': '/img[1]'})
            receipt, bundle, _ = acquisition(root)
            bundle.write_bytes(bundle.read_bytes()+b'changed')
            with self.assertRaises(ValueError): BodyAssetAdapter(receipt, bundle)

    def test_media_containers_reject_truncation_and_disguised_html(self):
        for extension, expected in [('png','image/png'), ('gif','image/gif'), ('jpg','image/jpeg')]:
            raw = (FIXTURES/('source.'+extension)).read_bytes()
            self.assertEqual(_media(raw)[0], expected)
            for changed in (raw[:-1], raw[:20], b'<html>error</html>'):
                with self.subTest(extension=extension), self.assertRaises(ValueError): _media(changed)

    def test_missing_unsafe_urls_and_partial_http_status_fail_closed(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); receipt,bundle,rows=acquisition(root)
            adapter=BodyAssetAdapter(receipt,bundle)
            for src in ('static/missing.png', '//other.test/a.png', 'javascript:alert(1)',
                        'https://user@lovdata.no/static/source.png', 'static/source.png#fragment'):
                with self.subTest(src=src), self.assertRaises(ValueError):
                    adapter.resolve(src, source_use={'path':'/img[1]'})
            rows[0]['status']=206;receipt,bundle,_=acquisition(root,rows=rows)
            with self.assertRaises(ValueError):BodyAssetAdapter(receipt,bundle)

    def test_forks_merge_only_accepted_uses_and_keep_verified_mime_and_trailing_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);receipt,bundle,rows=acquisition(root)
            rows[0]['content_type']='text/plain'
            content={'source.png': (FIXTURES/'source.png').read_bytes()+b'preserved trailing bytes',
                     'source.gif': (FIXTURES/'source.gif').read_bytes()}
            rows[0]['bytes']=len(content['source.png'])
            rows[0]['sha256']=hashlib.sha256(content['source.png']).hexdigest()
            receipt,bundle,_=acquisition(root,rows=rows,content=content)
            parent=BodyAssetAdapter(receipt,bundle);accepted=parent.fork();rejected=parent.fork()
            descriptor=accepted.resolve('static/source.png',source_use={'path':'/img[1]'})
            rejected.resolve('static/source.gif',source_use={'path':'/img[2]'})
            self.assertEqual(parent.used_assets(),[])
            self.assertEqual(descriptor['media_type'],'image/png')
            self.assertEqual(descriptor['declared_content_type'],'text/plain')
            self.assertEqual(descriptor['trailing_bytes'],len(b'preserved trailing bytes'))
            parent.merge_used(accepted);parent.merge_used(accepted)
            self.assertEqual(len(parent.used_assets()),1)
            self.assertEqual(len(parent.used_assets()[0]['source_uses']),1)
            with self.assertRaises(ValueError):parent.merge_used(BodyAssetAdapter(receipt,bundle))
            result=parent.export_used(root/'out')
            self.assertEqual((root/'out'/result['assets'][0]['path']).read_bytes(),content['source.png'])
