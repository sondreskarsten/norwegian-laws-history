# Next source-wrapper and parent/child batch proposal

This is a read-only proposal against v10's retained 5,874-document snapshot. Repository gates were not edited. Counts below are in-memory **grammar-only candidates**, not rendered, raw-qualified or delivered bodies.

| Proposed group | Additional candidates | Projected accepted | Remaining |
|---|---:|---:|---:|
| Browser-safe parent/child additions | 48 | 5,491 | 383 |
| Document/change wrappers, excluding bare replacement list items | 46 | 5,489 | 385 |
| Explicit deep heading divs | 4 | 5,447 | 427 |
| All three together | **99** | **5,542** | **332** |

The groups overlap and expose one another; do not add the individual counts. Media integration may change these totals independently, so rerun the combined gate against the final release.

## Suggested grouped implementation

1. Admit the observed safe flow edges: italic text containing a footnote reference; plain paragraphs and footnote footers within legal paragraphs; continuation paragraphs under sections/legal articles and footnotes; tables within centered paragraphs/footnote articles; lists in footnotes/list articles/change annotations. Keep the ancestor-level nested-anchor rejection. Table readback currently limits source parents, so explicitly extend its checked parent set for centered paragraphs and footnote articles rather than merely changing the grammar.
2. Add `article.document-change` and `article.change` as ordered element containers with the observed article/heading/list children. There are 189 document wrappers and 608 change blocks across 71 rejected documents. Preserve `data-document`, `data-add-new-part`, `data-change-part`, `data-repeal-part`, and `data-move-part` as bounded escaped source metadata. Values can contain multiple targets separated by spaces, and move pairs separated by `;;`; do not flatten them or treat their display as eligible operations. These attributes are evidence, not a reconstruction decision. Preserve exact order and all current text.
3. Admit `div.legalArticleHeader` with exact `role=heading`, observed `aria-level` 7/8/9, and optional observed alignment. Retain source heading-value/title spans, line breaks and footnote references. Add conditional heading presentation without changing the source role or previous body bytes.
4. Use a new version, mirrored producer/consumer code, focused real fixtures, full previous-payload continuity, all-addition raw qualification and desktop/mobile readback before publication.

Small representative candidates: `lov/2023-12-20-96` (whole-document repeal wrapper, captured model 2,105 bytes); `forskrift/1971-10-01-6` (footnote footer in legal paragraph, 3,908 bytes); `forskrift/1977-06-24-9453` (footnote reference inside italics, 18,833 bytes); `lov/1991-07-20-67` (deep headings, 242,267 bytes). Exact paths and additional candidates are in the scan report.

## Keep out of simple whitelisting

- **162 direct `li` replacement nodes under `article.change`:** they need an explicit source-bound derived list container or equivalent marker-preserving representation. Bare list items would not get the current exact-marker stylesheet and are not a faithful list implementation.
- **27 tables and 6 footnote footers inside source `p` elements:** tables/footer blocks cannot be emitted inside an HTML paragraph unchanged. Preserve the source tree but generate a recorded flow wrapper, reverse-checking it back to the original `p` and retaining its source identity. Do not drop the paragraph boundary or let the browser silently rearrange it.
- **26 nested source anchors and 30 footnote references inside anchors:** nested interactive anchors need a separate link-preserving representation. The present explicit rejection is correct until both source links can be recovered meaningfully.
- **One footnote footer within `h3`:** preserve the title and footnotes with a separately recorded structural transformation; avoid emitting block footnotes as heading text.

These are representation work, not evidence-access limitations. Specific malformed source cases may be discovered during that work, but the current generic HTML mismatch is not sufficient evidence to label a document permanently unsupported.

## Evidence

- `v10-wrapper-parent-inventory.json`: exact attributes, node/parent examples, paths, edges, first rejections and source counts.
- `v10-wrapper-proposal-scan.json`: all four scenario results, candidate refids, smallest cases and baseline gate SHA256.
- `v10-wrapper-baseline-gate.py`: frozen v10 gate used by the proposal.
- `propose-wrapper-grammar.py`: scratch-only in-memory scenario definitions.

No gate, product interface or public release changed for this proposal.
