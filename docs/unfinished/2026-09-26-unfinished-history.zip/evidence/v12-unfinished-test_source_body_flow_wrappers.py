"""Exact source change containers and browser-safe flow, with unsafe nesting rejected."""
import copy
import hashlib
import json
import unittest
from pathlib import Path
from law_history import source_body_gate as gate
from test_source_body_lists import captured

FIXTURES = Path(__file__).parent / 'fixtures/source_body'


class SourceFlowWrapperTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = json.loads((FIXTURES / 'flow-wrapper-source-members.json').read_text(encoding='utf-8'))

    def source(self, feature):
        record = next(r for r in self.rows if feature in r['features'])
        raw = (FIXTURES / record['retained_file']).read_bytes()
        return record, raw, captured(raw)

    def test_retained_body_order_targets_headings_and_nested_footnotes(self):
        features = set()
        for record in self.rows:
            with self.subTest(refid=record['refid']):
                raw = (FIXTURES / record['retained_file']).read_bytes()
                self.assertEqual(hashlib.sha256(raw).hexdigest(), record['member_sha256'])
                model = captured(raw)
                result = gate.qualify_source_body(raw, model, expected_refid=record['refid'],
                    expected_member_sha256=record['member_sha256'], source_occurrence_id=record['source_occurrence_id'])
                self.assertEqual(result['report']['status'], 'passed', result['report'])
                gate.verify_rendered_body(result['html'], model, stylesheet=result['stylesheet'])
                features.update(record['features'])
                for before, after in (('class="document-change"', 'class="change"'),
                                      ('role="heading"', 'role="button"'),
                                      ('data-source-body-derived="table-scroll"', 'data-source-body-derived="unknown"')):
                    if before in result['html']:
                        with self.subTest(tampered=before), self.assertRaises(gate.BodyRejected):
                            gate.verify_rendered_body(result['html'].replace(before, after, 1), model, stylesheet=result['stylesheet'])
        self.assertTrue({'document-change', 'deep-heading', 'footnote-table', 'italic-reference'} <= features, features)

    def test_change_metadata_is_exact_bounded_source_evidence(self):
        _, _, original = self.source('document-change')
        for value in ('', 'x' * 8193, 'lov/2020-01-01\nwrong'):
            model = copy.deepcopy(original)
            node = next(n for n, _, _ in gate._walk(model['root']) if gate._form(n) == ('article', 'document-change'))
            node['attributes']['data-document'] = value
            with self.subTest(value=value[:40]), self.assertRaises(gate.BodyRejected):
                gate._grammar(model['root'], model['context'])
        record, raw, model = self.source('document-change')
        result = gate.qualify_source_body(raw, model, expected_refid=record['refid'], expected_member_sha256=record['member_sha256'], source_occurrence_id=record['source_occurrence_id'])
        target = next(n['attributes']['data-document'] for n, _, _ in gate._walk(model['root']) if 'data-document' in n['attributes'])
        with self.assertRaises(gate.BodyRejected):
            gate.verify_rendered_body(result['html'].replace(target, 'lov/1900-01-01-1', 1), model, stylesheet=result['stylesheet'])

    def test_deep_heading_role_and_level_are_required(self):
        _, _, original = self.source('deep-heading')
        for attribute, value in (('aria-level', '0'), ('aria-level', '6'), ('aria-level', '10'), ('role', 'button')):
            model = copy.deepcopy(original)
            node = next(n for n, _, _ in gate._walk(model['root']) if gate._form(n) == ('div', 'legalArticleHeader'))
            node['attributes'][attribute] = value
            with self.subTest(attribute=attribute, value=value), self.assertRaises(gate.BodyRejected):
                gate._grammar(model['root'], model['context'])

    def test_unsafe_structures_are_not_whitelisted(self):
        _, _, original = self.source('document-change')
        model = copy.deepcopy(original)
        change = next(n for n, _, _ in gate._walk(model['root']) if gate._form(n) == ('article', 'change'))
        change['children'].append({'tag': 'li', 'attributes': {'data-name': 'a.', 'value': '1'}, 'children': []})
        with self.assertRaises(gate.BodyRejected):
            gate._grammar(model['root'], model['context'])
        for parent in (('p', ''), ('p', 'leddfortsettelse')):
            self.assertNotIn(('table', ''), gate._CHILDREN[parent])
            self.assertNotIn(('footer', 'footnotes'), gate._CHILDREN[parent])
        _, _, model = self.source('italic-reference')
        parent = next(n for n, _, _ in gate._walk(model['root']) if n['tag'] == 'i' and any(isinstance(c, dict) and gate._form(c) == ('sup', 'footnotereference') for c in n['children']))
        parent['tag'] = 'a'; parent['attributes'] = {'href': 'https://lovdata.no/'}
        with self.assertRaises(gate.BodyRejected):
            gate._grammar(model['root'], model['context'])
